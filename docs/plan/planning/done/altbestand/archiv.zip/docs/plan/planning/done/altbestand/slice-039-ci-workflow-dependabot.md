# Slice slice-039: CI-Workflow und Dependabot

**Lifecycle:** Der Zustand dieses Slice ist das Verzeichnis, in dem diese
Datei liegt — eines von `open/`, `next/`, `in-progress/`, `done/`. Er
wechselt nur durch `git mv`, siehe
Baseline-Regelwerk `modul-05-planning-harness.md` §Lifecycle als State Machine.

**Welle:** ohne Welle — reine Tooling-/Infrastruktur-Arbeit, kein
CDC-Fähigkeits-Zuwachs, keine Closure-Bedingung, die über die eigene DoD
hinausgeht (Baseline-Regelwerk `modul-06-roadmap.md` §Wann Arbeit eine
Welle braucht). Orthogonal zu `welle-12`, blockiert sie nicht.

**Bezug:**
[`ADR-0051`](../../../../docs/plan/adr/0051-cicd-pipeline-github-actions.md)
(nur umgesetzt — keine aktive ADR wird geändert, `ADR-0051` bleibt
`Accepted`), [`ADR-0045`](../../../../docs/plan/adr/0045-commit-traceability-standing-gate.md)
(bindet die Form der Dependabot-Commit-Messages).

**Berührte Spec-Stellen:** — (reine Tooling-Infrastruktur, keine
Verhaltensänderung an einer Spec-Stelle).
Der Verweis zeigt **aufwärts**: Die Spec nennt diesen Slice nie
(Baseline-Regelwerk `grundlagen-referenz-richtung.md`
§Referenz-Richtung (SDP), `grundlagen-source-precedence.md` §ID-Schema als Klammer).

**Verantwortlich:** pt9912.

**Autor:** pt9912. **Datum:** 2026-09-13.

---

## 1. Ziel und Abgrenzung

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Ziel-Form: Slice — Schnitt nach Lieferwert, nicht nach Schichten; jeder Slice
ist einzeln lieferbar. **§1 nennt Ziel und Abgrenzung** (Out-of-Scope-Disziplin
des Lastenhefts, auf den Slice-Plan angewandt); die vier Klassen des
Ausschlusses stehen in **eben diesem Abschnitt** des Baseline-Regelwerks,
zusammen mit der Begründungs-Pflicht je Punkt.

**Ziel:** `ADR-0051`s Entscheidungen 2 (CI-Workflow), 5 (Action-Pinning,
bereits in `AGENTS.md` §3.8 verkörpert) und 9 (Dependabot) real umsetzen:
`.github/workflows/ci.yml` läuft auf jeden Pull Request und Push
(`tags-ignore: ['**']`), ruft `make gates` und ergänzend `make test`
(Race-Detector) auf — beide Docker-only, kein separater `docker`-Aufruf
außerhalb `make` (`AGENTS.md` §3.1). `.github/dependabot.yml` deckt die
Ökosysteme `gomod` und `github-actions` ab, wöchentlich, mit
Commit-Message-Prefix `[ADR-0051]` (`ADR-0045`-konform). Alle
`uses:`-Zeilen SHA-gepinnt mit Tag-Kommentar (`AGENTS.md` §3.8).

**Ausdrücklich NICHT in diesem Slice** — je Punkt mit Begründung:

- **`make test-integration`/`test-store`/`test-replication` in der CI**
  — `ADR-0051`s Entscheidung 2 benennt das ausdrücklich als „Umfang:
  Folge-Slice"; diese DB-gebundenen Ziele bleiben kein Gate und laufen
  nach Bedarf, nicht zwingend bei jedem PR — eine eigene, größere
  Entscheidung (Runner-Ressourcenbedarf, Laufzeit), die dieser Slice
  nicht ungefragt trifft.
- **`release.yml`, `hub-description.yml`, `image-scan.yml`,
  `upstream-drift.yml`, `version.md`** — Folge-Slice `slice-040`
  übernimmt das explizit; diese Artefakte brauchen Registry-Secrets, die
  der Nutzer erst nach diesem Slice bereitstellt.
- **Ein erster echter Workflow-Lauf auf GitHub** — dieser Slice legt die
  Mechanik an; ob/wann ein PR oder Push den Workflow real auslöst, ist
  Sache des Nutzers nach dem Merge (siehe §6 Risiken zur
  Verifikationsgrenze).

**Keine Mindestzahl.** Ein Slice mit *einem* echten Ausschluss ist besser als
einer mit vier erfundenen; die vier Klassen sind ein Suchraster, keine
Ausfüll-Liste. Suchreihenfolge: Was übernimmt ein **Folge-Slice** (mit
Kennung — und die Kennung muss den Punkt auch annehmen)? Was bleibt als
**Bestand** bewusst stehen (mit Begründung)? Was wäre ein **anderer Vorgang**?
Welche **Schicht** rührt der Slice nicht an?

Was hier steht, ist die Grenze, an der ein wachsender Slice sich messen lässt:
Wer später etwas mitnimmt, das hier ausgeschlossen war, hat den Plan
**geändert**, nicht nur ergänzt.

## 2. Definition of Done

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Ziel-Form: Slice — **≤ 3 Liefer-Punkte**; mehr heißt: der Slice ist zu groß und
gehört zurück zur Zerlegung. Gezählt wird nur, was mit dem Umfang wächst — die
Gate-Läufe und die fünf Closure-Pflichten darunter zählen nicht mit.

- [x] `.github/workflows/ci.yml` angelegt: `pull_request` + `push`
      (`tags-ignore: ['**']`), `permissions: {}` auf Workflow-Ebene,
      `contents: read` auf Job-Ebene; ruft `make gates` und `make test`
      auf; Checkout-Action SHA-gepinnt mit Tag-Kommentar (`AGENTS.md`
      §3.8).
- [x] `.github/dependabot.yml` angelegt: `gomod` + `github-actions`,
      wöchentlich, `commit-message.prefix` `[ADR-0051]`, kein
      `docker`-Ecosystem.
- [x] Beide YAML-Dateien real syntaktisch valide (z. B. `yamllint`/
      `actionlint` im Toolchain-Container, falls verfügbar — sonst
      dokumentierte manuelle Prüfung im Plan-Nachzug).
- [x] `make gates` grün.
- [x] Review durchgeführt, Report unter `docs/reviews/` liegt vor
      (`.harness/skills/reviewer.md`) — Rollenwechsel nach Schritt 8 des
      Minimal Agent Workflow (`AGENTS.md` §6), kein Self-Review (Modul 8).
      Beleg: [`docs/reviews/review-slice-039.md`](../../../reviews/review-slice-039.md)
      (0 HIGH, 1 MEDIUM, 2 INFO), Fixrunde in Commit `a23305a`, bestätigt
      in [`docs/reviews/review-slice-039-fixrunde.md`](../../../reviews/review-slice-039-fixrunde.md).
      Verifikation in
      [`docs/reviews/verify-slice-039.md`](../../../reviews/verify-slice-039.md)
      (DoD eigenständig nachgeprüft, ein neues Finding V-1 zu dieser
      Checkbox selbst — hiermit nachgezogen).
- [x] Doku-Update: `harness/README.md` §Sensors — kein neues Gate (CI
      automatisiert nur bestehende `make gates`), aber ein Hinweis, dass
      PRs/Pushes jetzt automatisiert geprüft werden, gehört dorthin, falls
      die bestehende Tabellenform das zulässt; Implementer entscheidet und
      begründet im Plan-Nachzug.
- [x] Closure-Notiz mit Steering-Loop-Lerneintrag. Siehe §7.
- [x] Reconciliation-Register (`../reconciliation.md`) fortgeschrieben, **falls dieser Slice einen Inventur-Fund auflöst** — Zeile mit Datum und auflösendem Artefakt nach *Aufgelöste Einträge* verschoben. Repos ohne Brownfield-Bootstrap haben die Datei nicht; dann entfällt das Item. Entfällt: Repo ist Greenfield (`harness/conventions.md` Modus-Deklaration `PGC`), `../reconciliation.md` existiert nicht.
- [x] Beobachtungs-Register (`../observations/`) fortgeschrieben — neues Verzeichnis `BEO-<KUERZEL>/<slug>/` oder eine weitere Datei in dessen `evidence/`; **kein Zaehler wird gesetzt**, er folgt aus den Dateien. Keine Beobachtung angefallen ist ebenfalls eine Antwort und wird in §7 notiert. Siehe §7 — neues Verzeichnis `BEO-PGC/github-actions-unverifizierbar-lokal/` angelegt, Beleg `evidence/slice-039.md` (1×).
- [x] Jedes Risiko aus §6 trägt einen Ausgang (eingetreten / entfallen / weiter offen). Siehe §6 — beide *weiter offen*.
- [x] Die drei Paarungen (Anker · Folge-Slice · Register) sind getragen — im Repo **ohne** Wellen-Betrieb hier geprüft (dieser Slice ist wellenlos — die Prüfung läuft **hier**, nicht bei einer Welle-Closure). Siehe §7 — alle drei geprüft, kein Rot.

## 3. Plan (vor Code)

Regeln dieser Sektion: Baseline-Regelwerk `grundlagen-bootstrap.md`
§Was ist eine Sub-Area? — diese Liste liefert die **Pfad-Kandidaten** für §8,
nicht die Antwort: Pfad-Berührung ist nicht hinreichend, und eine
Aussagen-Berührung steht hier gar nicht.

| Datei / Komponente | Änderungs-Art | Begründung |
|---|---|---|
| `.github/workflows/ci.yml` | neu | PR-/Push-CI: `make gates` + `make test` |
| `.github/dependabot.yml` | neu | `gomod` + `github-actions`, wöchentlich |
| `harness/README.md` | update | Hinweis auf automatisierte CI, falls sinnvoll |

### Plan-Nachzug (Implementer, nach Umsetzung)

- **`make mod-download` als zusätzlicher Schritt vor `make test`.**
  `make test` läuft mit `--network none` gegen den Docker-Volume-
  Modulcache (Makefile-Kommentar „Vorbereitung: `make mod-download`");
  ohne den vorgeschalteten Lauf bricht `go test -race` auf einem frischen
  CI-Runner ohne befüllten Cache ab. Kein zusätzlicher Liefer-Punkt — reine
  Voraussetzung, damit das DoD-Item „ruft `make test` auf" real
  funktioniert, kein neues Artefakt und keine neue Fähigkeit.
- **`fetch-depth: 0` beim Checkout.** `make gates` schließt
  `commit-traceability` ein, das per Default gegen `HEAD~5..HEAD` prüft
  (`ADR-0045`). Der GitHub-Actions-Default-Checkout ist flach
  (`fetch-depth: 1`) und ließe `HEAD~5` bei jedem PR/Push mit weniger als
  sechs erreichbaren Commits ins Leere greifen bzw. dauerhaft mit nur
  einem Commit im Fenster laufen. Übernommen aus derselben Begründung wie
  im gelesenen `d-check`-Vorbild.
- **YAML-Realprüfung — vier unabhängige Belege statt nur `yamllint`:**
  (1) `python3 -c "import yaml; yaml.safe_load(...)"` für beide Dateien —
  strukturell parsebar; (2) `yamllint`; (3) `actionlint` (`rhysd/actionlint`,
  Docker-Pull) gegen `ci.yml` — exit 0, keine Befunde, GitHub-Actions-
  Workflow-Semantik (nicht nur YAML-Syntax) geprüft; (4) `jsonschema` gegen
  die offiziellen SchemaStore-Schemata. Keine dieser vier Prüfungen lief im
  repo-eigenen Toolchain-Container (kein `yamllint`/`actionlint`-Image dort
  verankert) — das ist dokumentierte manuelle/externe Docker-Prüfung im
  Sinne des DoD-Items, kein Repo-Sensor.

  **Korrektur nach Review (`review-slice-039.md` F-2, 2026-09-13):** Die
  ursprüngliche Fassung dieses Punkts behauptete für (2) „sauber bis auf
  eine Kommentar-Abstand-Warnung, behoben" — dieser Befund war falsch und
  ist beim ursprünglichen Lauf nicht so aufgetreten; der Reviewer hat
  `yamllint` eigenständig gegen den committeten Stand reproduziert (Default-
  Konfiguration, keine `.yamllint`-Datei existierte zu dem Zeitpunkt) und
  fand stattdessen 1 Error (`ci.yml:47:81`, Zeile zu lang) + 3 Warnings
  (fehlender Dokumentstart `---` in beiden Dateien, `truthy value`-Warnung
  auf `on:` in `ci.yml:27:1`) — keiner davon eine
  Kommentar-Abstand-Warnung. Nachvollzogen mit demselben Befund
  (`docker run --rm -v "$PWD":/repo -w /repo cytopia/yamllint:latest
  .github/workflows/ci.yml .github/dependabot.yml`, Default-Konfiguration).

  Real behoben statt nur umbeschrieben: `---`-Dokumentstart in beiden
  Dateien ergänzt; `on:` in `ci.yml` als `"on":` gequotet (behebt
  nebenbei auch das zuvor hier dokumentierte PyYAML-„Norway
  Problem" bei Prüfung (4) — `yaml.safe_load` liefert seither den
  String-Key `on`, nicht mehr den Bool-Key `True`); der Kommentar-Abstand
  vor dem Tag-Kommentar der Checkout-Action auf ein Leerzeichen vereinheit-
  licht (deckt sich exakt mit der Beispielform in `AGENTS.md` §3.8: `uses:
  actions/checkout@<sha> # v7.0.1`) und macht die Zeile zugleich 80 statt
  81 Zeichen lang. Diese Ein-Leerzeichen-Form weicht vom yamllint-Default
  (`comments.min-spaces-from-content: 2`) ab; dafür trägt das Repo neu
  `.yamllint` (`extends: default`, `comments.min-spaces-from-content: 1`,
  mit Begründung in der Datei selbst) — das Werkzeug wird an der bereits
  geltenden Hard Rule ausgerichtet, nicht umgekehrt.

  Erneuter Lauf nach der Korrektur: `docker run --rm -v "$PWD":/repo -w
  /repo cytopia/yamllint:latest -c .yamllint .github/workflows/ci.yml
  .github/dependabot.yml .yamllint` → Exit 0, keine Befunde. `actionlint`
  und der `python3`/PyYAML-Parse-Beleg wurden nach der Korrektur erneut
  gegen den geänderten Stand ausgeführt und bleiben unverändert grün bzw.
  strukturell valide.
- **`harness/README.md` §„Aktueller Lauf-Status"** statt einer neuen
  Zeile in der Sensors-Tabelle: Die Zeile referenzierte bereits vor diesem
  Slice ein „CI-Badge" als Platzhalter, ohne dass ein Workflow existierte.
  Ein echter Badge-Link plus ein Satz, dass `ci.yml` `make gates`
  (unverändert) und `make test` automatisiert, macht diese bereits
  bestehende Zusage wahr, statt eine neue Sensors-Zeile für etwas
  einzuführen, das kein neues Gate ist (`ADR-0051`, DoD-Item 6 —
  Implementer-Entscheidung: **ja, aber an der Lauf-Status-Zeile, nicht an
  der Tabelle**).
- **Kein GitHub-Workflow-Lauf ausgelöst.** Wie in §1/§6 vorgesehen bleibt
  die Verifikation auf die vier oben genannten statischen Prüfungen
  beschränkt; ein echter Lauf gegen GitHub Actions ist Sache des Nutzers
  nach dem Merge.

## 4. Trigger

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Trigger je Lifecycle-Übergang und WIP-Limit.

**Start** (`next` → `in-progress`): `ADR-0051` liegt `Accepted` vor,
`Verantwortlich:` gesetzt, WIP-Limit (1 je Implementer) frei.

**Rückführungen — vorab benennen, nicht erst im Nachhinein begründen:**

- `in-progress` → `next` (zu groß, zurück zur Zerlegung): Zeigt sich,
  dass `ci.yml` und `dependabot.yml` zusammen mehr als drei Liefer-Punkte
  brauchen (z. B. weil `make test` in CI eine größere Anpassung an den
  Toolchain-Container-Aufruf braucht als erwartet), gehört das zurück zur
  Zerlegung.
- `in-progress` → `open` (blockiert — Carveout?): Kein bekannter Blocker.

## 5. Closure-Trigger

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Closure- und Lerneintrag-Regeln — zwei beobachtbare Kriterien **und** ein
Lerneintrag; ohne ihn ist der Slice nur abgelegt.

DoD vollständig **und** `make gates` grün **und** Closure-Notiz geschrieben.

## 6. Risiken und offene Punkte

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Offene Risiken werden bei Closure aufgelöst — **jedes** Risiko bekommt genau
**einen** Ausgang, und kein Slice geht nach `done/`, während eines ohne Ausgang
dasteht.

- `ci.yml` kann vor einem echten GitHub-Push/PR nicht lokal real
  ausgeführt werden (GitHub Actions ist nicht in Docker simulierbar) —
  die Verifikation bleibt auf statische YAML-Prüfung und logische
  Nachvollziehbarkeit beschränkt, bis der Nutzer nach dem Merge einen
  echten PR/Push auslöst. **Ausgang: weiter offen** →
  `BEO-PGC/github-actions-unverifizierbar-lokal` im Register (Eintrag
  neu angelegt, 1×) — löst sich erst mit dem ersten echten Workflow-Lauf,
  Sache des Nutzers, kein Slice kann das repo-intern vorwegnehmen.
- `make test` im CI-Runner könnte einen anderen Ressourcen-/Zeitbedarf
  haben als lokal (Race-Detector-Build ist bereits als
  Debian-Toolchain-Image bekannt, größer als die Alpine-Variante) — ein
  GitHub-Actions-Runner-Timeout ist ohne realen Lauf nicht ausschließbar.
  **Ausgang: weiter offen** → dieselbe Beobachtung
  `BEO-PGC/github-actions-unverifizierbar-lokal` deckt auch dieses
  Risiko (beide sind Facetten derselben Grenze: kein realer
  GitHub-Actions-Lauf vor dem Merge), kein zweiter Registereintrag nötig.

## 7. Closure-Notiz

<!-- BEDIENHINWEIS — keine Norm; faellt beim Kopieren weg (README.md
§Verwendung, Schritt 5) und darf deshalb nichts Tragendes halten. Reihenfolge:
diese Sektion vor dem `git mv` nach done/ fuellen — einzige Ausnahme ist das
letzte DoD-Item in §2 (die Paarungen suchen in `done/`, also nach dem `git mv`).
Im Repo ohne Wellen-Betrieb braucht die Closure dadurch drei Commits: Inhalt,
`git mv`, Haekchen — das folgt aus der Hard Rule, es widerspricht ihr nicht. -->

Regeln dieser Sektion: Baseline-Regelwerk `modul-06-roadmap.md`
§Das Beobachtungs-Register (vorhandene `BEO-<NNN>` **zitieren** statt neu
formulieren — sonst zählt das Register zwei Namen getrennt) ·
`grundlagen-traceability.md` §Herkunfts-Anker für Steering-Loop-Regeln (das
Feld `liegt in` steht **nur**, wenn mit diesem Slice wirklich etwas verkörpert
wurde; Feld und Zielort auf **einer** Zeile, Sektionsangabe innerhalb der
Backticks).

- **Was hat funktioniert:** Der Implementer fand von sich aus zwei
  nicht im Plan vorweggenommene, aber notwendige Ergänzungen
  (`make mod-download` vor `make test`, `fetch-depth: 0` für
  `commit-traceability`) und begründete sie im Plan-Nachzug statt sie
  stillschweigend einzubauen. Die vierfache statische YAML-Prüfung
  (PyYAML-Parse, `yamllint`, `actionlint`, `jsonschema`) ging über das im
  DoD geforderte Minimum hinaus und deckte real, dass `actions/checkout`
  echt und nicht erfunden auf `v7.0.1` gepinnt ist (Reviewer-Beleg F-1).
- **Was ging anders als geplant:** Der Reviewer fand 1 MEDIUM (F-2): der
  ursprüngliche Plan-Nachzug behauptete einen falschen `yamllint`-Befund
  ("Kommentar-Abstand-Warnung, behoben" statt der tatsächlichen 1 Error +
  3 Warnings). Die Fixrunde reparierte real (Dokumentstart, `"on":`-Quoting,
  Kommentar-Abstand, neue `.yamllint`-Konfiguration) statt nur die
  Behauptung zu korrigieren, bestätigt in `review-slice-039-fixrunde.md`.
  Der Verifier fand zusätzlich ein eigenes Finding V-1: die
  "Review durchgeführt"-Checkbox war trotz vorliegender Reports nicht
  nachgezogen — hiermit in dieser Closure nachgeholt.
- **Steering-Loop-Eintrag:** Kein Eintrag erreicht mit diesem Slice 3× —
  `BEO-PGC/github-actions-unverifizierbar-lokal` ist neu und steht bei 1×.
- **Beobachtungs-Register (`../observations/`):**
  `BEO-PGC/github-actions-unverifizierbar-lokal/` neu angelegt, Beleg
  `evidence/slice-039.md` — Zähler steht bei 1×, beide §6-Risiken decken
  dieselbe Beobachtung ab.
- **Folge-Slices:** keine — die restliche CI/CD-Arbeit (`version.md`,
  `release.yml`, `hub-description.yml`, `image-scan.yml`,
  `upstream-drift.yml`) ist in `ADR-0051` als Slice B benannt, wird als
  `slice-040` erst beim nächsten Planungsschritt neu geschnitten und
  existiert noch nicht als Datei.
- **Risiken aus §6:** beide *weiter offen* → dieselbe neue Beobachtung
  `BEO-PGC/github-actions-unverifizierbar-lokal` — siehe §6.
- **Drei Paarungen (wellenlos, hier geprüft):** (a) Anker — kein
  Steering-Loop-Eintrag mit `liegt in`-Feld in diesem Slice, nichts zu
  prüfen. (b) Folge-Slice — keiner benannt (siehe oben), nichts zu
  prüfen. (c) Register — `BEO-PGC/github-actions-unverifizierbar-lokal/`
  existiert als Verzeichnis mit nicht leerem `evidence/`. Alle drei
  grün, kein Rot.

## 8. Sub-Area-Prüfungen und Modus-Begründung

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Ziel-Form: Sub-Area-Modus-Begründung — dort die **zwei vorgelagerten
Schritte** (sie stehen in jedem Slice-Plan, unabhängig von Modus und
Slice-Typ) und die **vier Pflichtkriterien** (Konventionen-Dichte ·
Phase-Reife · Evidenz-/Diskrepanz-Risiko · Reconciliation-Aufwand), vier und
nicht mehr.

**Der Abschnitt selbst entfällt nie.** Die zwei vorgelagerten Prüfungen laufen
in **jedem** Slice-Plan — sie hängen weder am Modus noch am Slice-Typ. Bedingt
ist allein der Modus-Begründungsblock am Ende; deshalb nennt der Titel beide
Hälften.

**Vorgelagert — Sub-Area-Wahl prüfen:** Einzige berührte Sub-Area ist die
Repo-weite Default-Sub-Area `*`/`PGC`.

**Vorgelagert — offene Beobachtungen sichten:** Register durchgegangen.
Keine Treffer für `PGC`, die spezifisch CI/CD-Infrastruktur betreffen.

**Modus-Begründungsblock — Umfang.** Pflicht, sobald mindestens eine berührte
Sub-Area BF oder Hybrid ist — einer pro Sub-Area. Bei reinem GF genügt der
Hinweis *"alle berührten Sub-Areas GF"*; bei reinem Refactor ohne neue
Sub-Area-Berührung entfällt **er** — nicht der Abschnitt.

Alle berührten Sub-Areas GF (nur `*`/`PGC`).
