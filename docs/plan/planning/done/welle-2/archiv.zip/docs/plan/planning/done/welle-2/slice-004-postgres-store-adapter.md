# Slice slice-004: PostgreSQL-ChangeStore-Adapter

**Lifecycle:** Der Zustand dieses Slice ist das Verzeichnis, in dem diese
Datei liegt — eines von `open/`, `next/`, `in-progress/`, `done/`. Er
wechselt nur durch `git mv`, siehe
Baseline-Regelwerk `modul-05-planning-harness.md` §Lifecycle als State Machine.

**Welle:** welle-2.

**Bezug:** [`LH-QA-REL-001`](../../../../spec/lastenheft.md), [`LH-QA-REL-002`](../../../../spec/lastenheft.md), [`ADR-0010`](../../../../docs/plan/adr/README.md), [`ADR-0032`](../../../../docs/plan/adr/README.md)

**Berührte Spec-Stellen:** [`SPEC-001`](../../../../spec/pflichtenheft.md), [`SPEC-002`](../../../../spec/pflichtenheft.md), [`ARC-009`](../../../../spec/architecture.md), [`ARC-006`](../../../../spec/architecture.md)
Der Verweis zeigt **aufwärts**: Die Spec nennt diesen Slice nie
(Baseline-Regelwerk `grundlagen-referenz-richtung.md`
§Referenz-Richtung (SDP), `grundlagen-source-precedence.md` §ID-Schema als Klammer).

**Verantwortlich:** pt9912 (Implementer-Rolle, Agent-Lauf).
**Autor:** pt9912. **Datum:** 2026-09-09.

---

## 1. Ziel und Abgrenzung

<!-- BEDIENHINWEIS: Ziel = ein Satz, Liefer-Fokus, kein "wir machen
aufraeumen". Abgrenzung = je Punkt eine Begruendung, nicht nur eine Nennung:
ein Ausschluss ohne Grund ist eine Behauptung. Keine Mindestzahl — ein echter
Ausschluss ist besser als vier erfundene. -->

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Ziel-Form: Slice — Schnitt nach Lieferwert, nicht nach Schichten; jeder Slice
ist einzeln lieferbar. **§1 nennt Ziel und Abgrenzung** (Out-of-Scope-Disziplin
des Lastenhefts, auf den Slice-Plan angewandt); die vier Klassen des
Ausschlusses stehen in **eben diesem Abschnitt** des Baseline-Regelwerks,
zusammen mit der Begründungs-Pflicht je Punkt.

**Ziel:** Der reale `PostgresChangeStoreAdapter`: Persist mit Deduplizierung über die interne Transaktions-ID (Idempotenz-Kontrakt, [`ADR-0011`](../../../../docs/plan/adr/README.md)), deterministisches Lesen, Position-Verwaltung — gegen reale PostgreSQL-Tabellen je [`SPEC-001`](../../../../spec/pflichtenheft.md)/[`SPEC-002`](../../../../spec/pflichtenheft.md), mit Adapter-Tests gegen eine reale Testcontainer-PostgreSQL.

**Ausdrücklich NICHT in diesem Slice** — je Punkt mit Begründung:

- Reale Replication-Stream-Integration — ein Folge-Slice übernimmt es
  (slice-005); der Store wird hier unabhängig von der Stream-Seite real.
- Consumer-Use-Cases und Retention-Adapter — es wäre ein anderer Vorgang
  (nicht MVP, [`ADR-0028`](../../../../docs/plan/adr/README.md)-Rest).
- Schreibpfad-Performance-Tuning — Messungen folgen mit dem
  MVP-Integrationstest (slice-006).

- *Plan-Nachzug (Review F-1, slice-004):* (b) „Position-Verwaltung" ist
  enger gefasst als der Plan-Text — Commit-Positionen je Transaktion als
  Ordnungs-/Bereichs-Größe des Lesens; Source-ACK-/Consumer-Positionen
  bleiben bei [`ReplicationAckPort`](../../../../docs/plan/adr/README.md) /
  [`ConsumerStatePort`](../../../../docs/plan/adr/README.md) (slice-005/006) — Plan-**Ergänzung**
  (trägt sich aus §1-Ausschlüssen slice-005/006). *Konsequenz (d):* die
  DDL trägt die Consumer-/Capture-State-Tabellen von [`SPEC-001`](../../../../spec/pflichtenheft.md)
  **bewusst nicht** (ihre Ports liegen außerhalb des Store-Adapters,
  slice-005/006) — das ist die eine **Plan-Änderung** dieses Slices, hier
  nachgezogen statt still.
- **Keine Mindestzahl.** Ein Slice mit *einem* echten Ausschluss ist besser als
einer mit vier erfundenen; die vier Klassen sind ein Suchraster, keine
Ausfüll-Liste. Suchreihenfolge: Was übernimmt ein **Folge-Slice** (mit
Kennung — und die Kennung muss den Punkt auch annehmen)? Was bleibt als
**Bestand** bewusst stehen (mit Begründung)? Was wäre ein **anderer Vorgang**?
Welche **Schicht** rührt der Slice nicht an?

Was hier steht, ist die Grenze, an der ein wachsender Slice sich messen lässt:
Wer später etwas mitnimmt, das hier ausgeschlossen war, hat den Plan
**geändert**, nicht nur ergänzt.

## 2. Definition of Done

<!-- BEDIENHINWEIS: je Zeile ein pruefbares Kriterium. -->

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Ziel-Form: Slice — **≤ 3 Liefer-Punkte**; mehr heißt: der Slice ist zu groß und
gehört zurück zur Zerlegung. Gezählt wird nur, was mit dem Umfang wächst — die
Gate-Läufe und die fünf Closure-Pflichten darunter zählen nicht mit.

- [x] `PostgresChangeStoreAdapter` persistiert committed Transaktionen
      deduplizierbar (Idempotenz-Kontrakt [`ADR-0011`](../../../../docs/plan/adr/README.md):
      dieselbe Transaktion erneut → höchstens erneute Verarbeitung) —
      Teil-Beleg zu [`LH-FA-RET-001`](../../../../spec/lastenheft.md).
- [x] Deterministisches Lesen über [`SPEC-001`](../../../../spec/pflichtenheft.md)-Tabellen
      (Bereich/Limit/Filter) — Teil-Beleg zu
      [`LH-FA-REA-001`](../../../../spec/lastenheft.md)…006.
- [x] `make gates` grün.
- [x] Review durchgeführt, Report unter `docs/reviews/` liegt vor
      (`.harness/skills/reviewer.md`) — Rollenwechsel nach Schritt 8 des
      Minimal Agent Workflow (`AGENTS.md` §6), kein Self-Review (Modul 8).
      *Beleg: review-slice-004.md.*
- [x] Doku-Update — getragen: die Werkzeuge-Zeilen (`make test`,
      `make test-store`, `make mod-download`) und der pgx-Layer-Hinweis
      im Dockerfile-Kopf sind über den Verifier-Lauf bestätigt
      (`harness/README.md`, Dockerfile). *Korrektur (V-3): die
      Erst-Begründung „nur `internal/**`" trug nicht — die Range ändert
      die Doku-Bestände.*
- [x] Closure-Notiz mit Steering-Loop-Lerneintrag. (*§7*)
- [x] Reconciliation-Register — **entfällt**: Repos ohne
      Brownfield-Bootstrap haben die Datei nicht., **falls dieser Slice einen Inventur-Fund auflöst** — Zeile mit Datum und auflösendem Artefakt nach *Aufgelöste Einträge* verschoben. Repos ohne Brownfield-Bootstrap haben die Datei nicht; dann entfällt das Item.
- [x] Beobachtungs-Register fortgeschrieben — **keine Beobachtung
      angefallen** (die `adapters`-Globs matchen Content, kein
      Abdeckungs-/Auflösungs-Hinweis; die verkörperte Beobachtung
      `BEO-PGC/a-check-null-abdeckung` ist nicht erneut aufgetreten). — neues Verzeichnis `BEO-<KUERZEL>/<slug>/` oder eine weitere Datei in dessen `evidence/`; **kein Zaehler wird gesetzt**, er folgt aus den Dateien. Keine Beobachtung angefallen ist ebenfalls eine Antwort und wird in §7 notiert.
- [x] Jedes Risiko aus §6 trägt einen Ausgang (siehe §7).
- [ ] Die drei Paarungen (Anker · Folge-Slice · Register) sind getragen — im Repo **ohne** Wellen-Betrieb hier geprüft, im Repo **mit** Wellen von der nächsten Welle-Closure (auch für Slices ohne Wellen-Zugehörigkeit).

## 3. Plan (vor Code)

<!-- BEDIENHINWEIS: Datei- oder Komponenten-Ebene reicht; der
Implementer-Agent erweitert die Liste in seinem ersten Lauf. -->

Regeln dieser Sektion: Baseline-Regelwerk `grundlagen-bootstrap.md`
§Was ist eine Sub-Area? — diese Liste liefert die **Pfad-Kandidaten** für §8,
nicht die Antwort: Pfad-Berührung ist nicht hinreichend, und eine
Aussagen-Berührung steht hier gar nicht.

| Datei / Komponente | Änderungs-Art | Begründung |
|---|---|---|
| `internal/adapters/driven/postgresstorage/*.go` | neu | row-Typen, `queries/`, `mapper/` je [`ADR-0039`](../../../../docs/plan/adr/README.md); [`SPEC-001`](../../../../spec/pflichtenheft.md)-Schema-DDL |
| `internal/adapters/driven/postgresstorage/*_test.go` | neu | Adapter-Tests gegen reale PostgreSQL (Testcontainer im gepinnten Docker-Netz) |
| `internal/application/port/outbound/changestore.go` | geändert | Lesefähigkeit am Fähigkeits-Port (`ADR-0009`: Lesen und Schreiben an einem Port) mit Kontrakt-Typen am Port (`ADR-0042`); der Port-Vertrag ist eine öffentliche Stelle (`ADR-0009` Negativ) |
| `internal/adapters/driven/postgresstorage/schema.sql` | neu | Schema-DDL (`SPEC-001`/`SPEC-002`) als eingebettete Datei |
| `go.mod`, `go.sum` | geändert | gepinnter nativer Go-Treiber (pgx/v5, CGO-frei — [`ADR-0038`](../../../../docs/plan/adr/README.md) bleibt fortgeltend); `go.sum` füllt sich erstmals |
| `Makefile`, `tools/harness/run-store-tests.sh` | neu | Test-Targets im gepinnten Toolchain-Container (`make test` netzlos, `make test-store` mit PostgreSQL-Testcontainer); kein Gate |

## 4. Trigger

<!-- BEDIENHINWEIS: Beispiele — "Wenn Welle X done." / "Wenn Carveout CO-NN
aufgeloest." -->

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Trigger je Lifecycle-Übergang und WIP-Limit.

**Start** (`next` → `in-progress`): slice-003 liegt in `done/` (Ports und Service existieren); kein anderes
Slice in `in-progress/` (WIP-Limit 1).

**Rückführungen — vorab benennen, nicht erst im Nachhinein begründen:**

- `in-progress` → `next` (zu groß, zurück zur Zerlegung): wächst der
  Adapter-Scope über die drei Liefer-Punkte hinaus (z. B. die Leseseite
  verdient einen eigenen Slice) → aufteilen.
- `in-progress` → `open` (blockiert — Carveout?): Treiber-/Testcontainer-
  Faktoren (PostgreSQL-Image nicht erreichbar) blockieren den realen Lauf.

## 5. Closure-Trigger

<!-- BEDIENHINWEIS: z.B. "DoD vollstaendig + PR gemerged + Closure-Notiz
geschrieben." -->

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Closure- und Lerneintrag-Regeln — zwei beobachtbare Kriterien **und** ein
Lerneintrag; ohne ihn ist der Slice nur abgelegt.

DoD (§2) vollständig abgehakt · Tests im Toolchain-Container grün ·
Review-Report unter `docs/reviews/` · Closure-Notiz mit Lerneintrag.

## 6. Risiken und offene Punkte

<!-- BEDIENHINWEIS: Was koennte schief gehen? Welche Carveouts entstehen
ggf.? Die drei Ausgaenge stehen als Form in der Zeile darunter. -->

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Offene Risiken werden bei Closure aufgelöst — **jedes** Risiko bekommt genau
**einen** Ausgang, und kein Slice geht nach `done/`, während eines ohne Ausgang
dasteht.

- (a) Die reale Idempotenz-Deduplizierung ist stärker als der Fake —
  **Ausgang:** weiter offen; der Adapter-Test belegt sie, der
  slice-003-Ausgang trägt den Termin (Welle 2).
- (b) Row-Images liefern nicht alle Werte je Operationstyp (REPLICA
  IDENTITY) — **Ausgang:** weiter offen; Bewertung mit dem
  Integrationstest (slice-006).

## 7. Closure-Notiz

<!-- BEDIENHINWEIS — keine Norm; faellt beim Kopieren weg (README.md
§Verwendung, Schritt 5) und darf deshalb nichts Tragendes halten. Reihenfolge:
diese Sektion vor dem `git mv` nach done/ fuellen — einzige Ausnahme ist das
letzte DoD-Item in §2 (die Paarungen suchen in `done/`, also nach dem `git mv`).
Im Repo ohne Wellen-Betrieb braucht die Closure dadurch drei Commits: Inhalt,
`git mv`, Haekchen — das folgt aus der Hard Rule, es widerspricht ihr nicht. -->

Regeln dieser Sektion: Baseline-Regelwerk `modul-06-roadmap.md`
§Das Beobachtungs-Register (vorhandene `BEO-<NNN>` **zitieren** statt neu
formulieren — sonst zählt das Register zwei Namen getrennt) ·
`grundlagen-traceability.md` §Herkunfts-Anker für Steering-Loop-Regeln (das
Feld `liegt in` steht **nur**, wenn mit diesem Slice wirklich etwas verkörpert
wurde; Feld und Zielort auf **einer** Zeile, Sektionsangabe innerhalb der
Backticks).

- **Was hat funktioniert:** die Idempotenz- und Ordnungs-Zusagen tragen
  echte Mutations-Proben am realen Treiber (Deduplizierung, Sortierung —
  implementer-seitig rot gesehen); die Fehlerklassen-Grenze
  ([`ADR-0023`](../../../../docs/plan/adr/README.md), Klasse `storage` am
  Port-Sentinel) trägt Adapter- und Commit-Ausgänge mit
  `errors.Is`-Lesbarkeit; der Schema-Loader-Defekt (Kommentar-Split) war
  eine Rücksprungkante 15→13 mit sauberem Fix.
- **Was ging anders als geplant:** die Review- und Verifier-Läufe
  überlappten mit parallelen Zugriffen auf denselben Arbeitsbaum — zwei
  gemischte Commits (`13abe88`, `e3e36f2`: Implementer-Test/Content +
  Review-/Plan-Artefakte) und eine verdrängte Review-Basis (`193716e`)
  sind die Folge; dokumentiert, nicht still. Konsequenz für den nächsten
  Zyklus: Rollen-Läufe auf dem Hauptzweig strikt sequenzieren
  (Implementer-Fix-Zug **endet**, bevor Review/Verifier-Artefakte
  committet werden); der Compile-/Test-Beleg als Gate ist der
  Steering-Loop-Kandidat aus Review F-7 (Welle-2-Closure).
- **Steering-Loop-Eintrag:** *F-2-Schiedsspruch: der `image-hash`-Beleg
  ist der Digest des exportierten Images und **builder-gebunden** — der
  Vergleich über Umgebungen hinweg kann Staleness nicht entscheiden;
  entscheidbar am Inhalt (Binary byte-identisch). Deklaration*
  — liegt in `Dockerfile`-Kopf und `harness/README.md` Werkzeuge-Zeile ·
  seit slice-004. *(Zusätzlich aus der Klasse „Datei-Ende-Zeilen fehlen"
  (3. Auftreten, V-4): Ausgang folgt in der Welle-2-Closure.)*
- **Beobachtungs-Register (`../observations/`):** **keine Beobachtung
  angefallen** — die `adapters`-Globs matchen Content ohne
  Abdeckungs-/Auflösungs-Hinweis; die verkörperte Beobachtung
  `BEO-PGC/a-check-null-abdeckung` ist nicht erneut aufgetreten.
- **Folge-Slices:** keiner aus diesem Slice — slice-005 (Stream-Adapter)
  folgt in der Welle-Sequenz (Datei in `open/`).
- **Risiken aus §6:** Risiko (a) reale Idempotenz → **entfallen** (belegt
  am realen Treiber, Idempotenz-Tests); Risiko (b) Row-Images/REPLICA
  IDENTITY → **weiter offen** (bewertet im Integrationstest, slice-006).
- **Drei Paarungen:** im Wellen-Betrieb an die Welle-2-Closure delegiert.

## 8. Sub-Area-Prüfungen und Modus-Begründung

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Ziel-Form: Sub-Area-Modus-Begründung — dort die **zwei vorgelagerten
Schritte** (sie stehen in jedem Slice-Plan, unabhängig von Modus und
Slice-Typ) und die **vier Pflichtkriterien** (Konventionen-Dichte ·
Phase-Reife · Evidenz-/Diskrepanz-Risiko · Reconciliation-Aufwand), vier und
nicht mehr.

**Der Abschnitt selbst entfällt nie.** Die zwei vorgelagerten Prüfungen laufen
in **jedem** Slice-Plan — sie hängen weder am Modus noch am Slice-Typ. Bedingt
ist allein der Modus-Begründungsblock am Ende; deshalb nennt der Titel beide
Hälften.

**Vorgelagert — Sub-Area-Wahl prüfen:** berührte Sub-Area:
PostgreSQL-Treiber-Integration (`internal/adapters/driven/**` bzw.
`driving/replication/**`, Compose-Umgebung); Achsen: (1) Konventionen-
Dichte — Adapter-Form in [`ADR-0039`](../../../../docs/plan/adr/README.md), Schichten-Constraints in
[`ADR-0002`](../../../../docs/plan/adr/README.md), Maschinenform in `.a-check.yml` (Edges aktiv);
(2) Phase-Reife — Phase 4 (Spec + ADRs + Domain/Ports committet, Adapter
entstehen); (3) Evidenz-Risiko niedrig (GF). Schwelle ≥ 2 erfüllt.

**Vorgelagert — offene Beobachtungen sichten:** das Register trägt nur
  den verkörperten Eintrag `BEO-PGC/a-check-null-abdeckung` (Ausgang
  `verkörpert · seit welle-1`) — **keine offenen Treffer**; notiert.

**Modus-Begründungsblock — Umfang.** Pflicht, sobald mindestens eine berührte
Sub-Area BF oder Hybrid ist — einer pro Sub-Area. Bei reinem GF genügt der
Hinweis *"alle berührten Sub-Areas GF"*; bei reinem Refactor ohne neue
Sub-Area-Berührung entfällt **er** — nicht der Abschnitt.

**Modus-Begründungsblock:** alle berührten Sub-Areas GF (Deklaration
`harness/conventions.md`, Default-Zeile) — kein BF/Hybrid, kein Block.
