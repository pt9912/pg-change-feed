# Slice slice-014: Strukturiertes Logging

**Lifecycle:** Der Zustand dieses Slice ist das Verzeichnis, in dem diese
Datei liegt — eines von `open/`, `next/`, `in-progress/`, `done/`. Er
wechselt nur durch `git mv`, siehe
Baseline-Regelwerk `modul-05-planning-harness.md` §Lifecycle als State Machine.

**Welle:** welle-4.

**Bezug:** [`LH-QA-OPS-004`](../../../../spec/lastenheft.md), [`ADR-0024`](../../../../docs/plan/adr/README.md)

**Berührte Spec-Stellen:** [`ARC-006`](../../../../spec/architecture.md)
Der Verweis zeigt **aufwärts**: Die Spec nennt diesen Slice nie
(Baseline-Regelwerk `grundlagen-referenz-richtung.md`
§Referenz-Richtung (SDP), `grundlagen-source-precedence.md` §ID-Schema als Klammer).

**Verantwortlich:** pt9912.

**Autor:** pt9912. **Datum:** 2026-09-10.

---

## 1. Ziel und Abgrenzung

<!-- BEDIENHINWEIS: Ziel = ein Satz, Liefer-Fokus, kein "wir machen
aufraeumen". Abgrenzung = je Punkt eine Begruendung, nicht nur eine Nennung:
ein Ausschluss ohne Grund ist eine Behauptung. Keine Mindestzahl — ein echter
Ausschluss ist besser als vier erfundene. -->

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Ziel-Form: Slice — Schnitt nach Lieferwert, nicht nach Schichten; jeder Slice
ist einzeln lieferbar. **§1 nennt Ziel und Abgrenzung** (Out-of-Scope-Disziplin
des Lastenhefts, auf den Slice-Plan angewandt); die vier Klassen des
Ausschlusses stehen in **eben diesem Abschnitt** des Baseline-Regelwerks,
zusammen mit der Begründungs-Pflicht je Punkt.

**Ziel:** Strukturiertes Logging über `log/slog` (Go-Standardbibliothek,
keine neue Abhängigkeit) am Bootstrap und an den Driven-Adaptern —
maschinenlesbare Log-Ausgabe (JSON-Handler) statt unstrukturierter
`fmt.Println`/`log.Printf`-Reste.

**Ausdrücklich NICHT in diesem Slice** — je Punkt mit Begründung:

- Log-Aggregation/-Versand an externe Systeme — anderer Vorgang
  (Integration mit externem Log-Stack, kein Bedarf beobachtet, Betreiber
  liest stdout/stderr des Containers).
- Domänen-interne Log-Aufrufe (`internal/domain/`) — Schicht-Abgrenzung:
  der Domain-Core bleibt frei von Treibern und Frameworks
  ([`ADR-0001`](../../../../docs/plan/adr/README.md)), Logging ist eine
  Infrastruktur-Fähigkeit außerhalb der Domäne
  ([`ADR-0024`](../../../../docs/plan/adr/README.md)).

**Keine Mindestzahl.** Ein Slice mit *einem* echten Ausschluss ist besser als
einer mit vier erfundenen; die vier Klassen sind ein Suchraster, keine
Ausfüll-Liste. Suchreihenfolge: Was übernimmt ein **Folge-Slice** (mit
Kennung — und die Kennung muss den Punkt auch annehmen)? Was bleibt als
**Bestand** bewusst stehen (mit Begründung)? Was wäre ein **anderer Vorgang**?
Welche **Schicht** rührt der Slice nicht an?

Was hier steht, ist die Grenze, an der ein wachsender Slice sich messen lässt:
Wer später etwas mitnimmt, das hier ausgeschlossen war, hat den Plan
**geändert**, nicht nur ergänzt.

## 2. Definition of Done

<!-- BEDIENHINWEIS: je Zeile ein pruefbares Kriterium. -->

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Ziel-Form: Slice — **≤ 3 Liefer-Punkte**; mehr heißt: der Slice ist zu groß und
gehört zurück zur Zerlegung. Gezählt wird nur, was mit dem Umfang wächst — die
Gate-Läufe und die fünf Closure-Pflichten darunter zählen nicht mit.

- [x] `slog`-JSON-Handler am Bootstrap verdrahtet, Log-Level über ENV
      konfigurierbar — Teil-Beleg zu
      [`LH-QA-OPS-004`](../../../../spec/lastenheft.md).
- [x] Driven-Adapter (Store, Aktivierung, Consumer-State,
      Replication-Ack) protokollieren strukturiert statt mit
      `fmt`/`log`-Resten — Teil-Beleg zu
      [`LH-QA-OPS-004`](../../../../spec/lastenheft.md).
- [x] `make gates` grün.
- [x] Review durchgeführt, Report unter `docs/reviews/` liegt vor
      (`.harness/skills/reviewer.md`) — Rollenwechsel nach Schritt 8 des
      Minimal Agent Workflow (`AGENTS.md` §6), kein Self-Review (Modul 8).
- [x] Doku-Update für `compose.yaml` (ENV-Vertrag um Log-Level-Variable
      erweitert), falls berührt.
- [x] Closure-Notiz mit Steering-Loop-Lerneintrag.
- [x] Reconciliation-Register (`../reconciliation.md`) fortgeschrieben, **falls dieser Slice einen Inventur-Fund auflöst** — Zeile mit Datum und auflösendem Artefakt nach *Aufgelöste Einträge* verschoben. Repos ohne Brownfield-Bootstrap haben die Datei nicht; dann entfällt das Item.
- [x] Beobachtungs-Register (`../observations/`) fortgeschrieben — neues Verzeichnis `BEO-<KUERZEL>/<slug>/` oder eine weitere Datei in dessen `evidence/`; **kein Zaehler wird gesetzt**, er folgt aus den Dateien. Keine Beobachtung angefallen ist ebenfalls eine Antwort und wird in §7 notiert.
- [x] Jedes Risiko aus §6 trägt einen Ausgang (eingetreten / entfallen / weiter offen).
- [x] Die drei Paarungen (Anker · Folge-Slice · Register) sind getragen — im Repo **ohne** Wellen-Betrieb hier geprüft, im Repo **mit** Wellen von der nächsten Welle-Closure (auch für Slices ohne Wellen-Zugehörigkeit).

## 3. Plan (vor Code)

<!-- BEDIENHINWEIS: Datei- oder Komponenten-Ebene reicht; der
Implementer-Agent erweitert die Liste in seinem ersten Lauf. -->

Regeln dieser Sektion: Baseline-Regelwerk `grundlagen-bootstrap.md`
§Was ist eine Sub-Area? — diese Liste liefert die **Pfad-Kandidaten** für §8,
nicht die Antwort: Pfad-Berührung ist nicht hinreichend, und eine
Aussagen-Berührung steht hier gar nicht.

| Datei / Komponente | Änderungs-Art | Begründung |
|---|---|---|
| `internal/bootstrap/wiring.go` | update | `slog.NewJSONHandler` verdrahtet, Log-Level aus `CDC_LOG_LEVEL` (ENV-Vertrag, [`ADR-0026`](../../../../docs/plan/adr/README.md) Composition Root) |
| `internal/adapters/driven/postgresstorage/*.go` | update | strukturierte Log-Aufrufe statt `fmt`/Standard-`log`-Reste |
| `internal/adapters/driving/replication/receive/receive.go` | update | strukturierte Log-Aufrufe am Stream-Adapter |
| `compose.yaml` | update | `CDC_LOG_LEVEL`-Variable im ENV-Vertrag |

**Plan-Nachzug (Fix-Zug, Baseline-Regelwerk `modul-09-implementierung.md`
„Plan-Nachzug im selben Lauf" · seit slice-009):** Review-Finding F-1
(HIGH, [`docs/reviews/review-slice-014.md`](../../../../docs/reviews/review-slice-014.md))
und das Architect-Verdikt
[`docs/plan/adr/architect-review-slice-014.md`](../../../reviews/architect-review-slice-014.md)
verlangen strukturiertes Logging über einen Outbound Port + Driven Adapter
statt eines globalen `slog`-Singletons ([`ADR-0024`](../../../../docs/plan/adr/README.md)).
Zusätzlich zu den vier Zeilen oben liefert der Fix-Zug:

| Datei / Komponente | Änderungs-Art | Begründung |
|---|---|---|
| `internal/adapters/driven/postgresack/ack.go` | update | strukturierte Log-Aufrufe am Replication-Ack-Adapter — war bereits im ersten Zug berührt, fehlte aber als eigene Zeile in diesem Plan (Nachtrag) |
| `internal/application/port/outbound/log.go` | neu | `LogPort`-Schnittstelle (vier Stufen, spiegelt `log/slog`) + `NoopLog`-Default, `ADR-0024` |
| `internal/adapters/driven/telemetry/slog.go`, `slog_internal_test.go` | neu | `SlogAdapter` als einzige Driven-Implementierung des `LogPort`, JSON-Handler-Bau — löst `bootstrap.newLogger`/`slog.SetDefault` ab |
| `internal/adapters/driven/postgresstorage/options.go` | neu | geteilte `Option`/`WithLog`-Infrastruktur der vier `postgresstorage`-Konstruktoren (variadisch, bestehende Aufrufstellen bleiben unverändert kompilierbar) |
| `internal/application/port/outbound/log_test.go` | neu | Testdouble-Beleg für `LogPort` (Substitution ohne globalen Zustand) |

## 4. Trigger

<!-- BEDIENHINWEIS: Beispiele — "Wenn Welle X done." / "Wenn Carveout CO-NN
aufgeloest." -->

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Trigger je Lifecycle-Übergang und WIP-Limit.

**Start** (`next` → `in-progress`): slice-013 liegt in `done/`; kein anderes
Slice in `in-progress/` (WIP-Limit 1).

**Rückführungen — vorab benennen, nicht erst im Nachhinein begründen:**

- `in-progress` → `next` (zu groß, zurück zur Zerlegung): Bootstrap-Handler
  plus Umstellung aller Driven-Adapter plus Replication-Adapter sprengen
  drei Liefer-Punkte — Rückzug mit Zerlegung (Bootstrap-Handler getrennt
  von der Adapter-Umstellung).
- `in-progress` → `open` (blockiert — Carveout?): kein bekannter Blocker;
  reine Infrastruktur-Ergänzung ohne externe Abhängigkeit.

## 5. Closure-Trigger

<!-- BEDIENHINWEIS: z.B. "DoD vollstaendig + PR gemerged + Closure-Notiz
geschrieben." -->

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Closure- und Lerneintrag-Regeln — zwei beobachtbare Kriterien **und** ein
Lerneintrag; ohne ihn ist der Slice nur abgelegt.

- DoD vollständiges Häkchen + `make gates` grün + Review-Schluss ohne
  offenes HIGH-Finding; die JSON-Log-Struktur ist am realen
  Integrationstest-Lauf beobachtbar (stdout-Diff).
- Lerneintrag §7: geschärfte Regel oder benannte Spec-Lücke — ohne ihn
  bleibt der Slice abgelegt, nicht fertig.

## 6. Risiken und offene Punkte

<!-- BEDIENHINWEIS: Was koennte schief gehen? Welche Carveouts entstehen
ggf.? Die drei Ausgaenge stehen als Form in der Zeile darunter. -->

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Offene Risiken werden bei Closure aufgelöst — **jedes** Risiko bekommt genau
**einen** Ausgang, und kein Slice geht nach `done/`, während eines ohne Ausgang
dasteht.

- Ein bestehender `fmt.Println`/`log.Printf`-Aufruf könnte übersehen
  werden — **Ausgang:** entfallen; geprüft (Implementer + Verifier
  unabhängig), keine Reste im berührten Scope (nur ein vorbestehender
  `fmt.Printf` für `--version`-CLI-Ausgabe in `cmd/pg-change-feed/main.go`,
  außerhalb des Slice-Scopes — CLI-Ausgabe, kein Log).

## 7. Closure-Notiz

<!-- BEDIENHINWEIS — keine Norm; faellt beim Kopieren weg (README.md
§Verwendung, Schritt 5) und darf deshalb nichts Tragendes halten. Reihenfolge:
diese Sektion vor dem `git mv` nach done/ fuellen — einzige Ausnahme ist das
letzte DoD-Item in §2 (die Paarungen suchen in `done/`, also nach dem `git mv`).
Im Repo ohne Wellen-Betrieb braucht die Closure dadurch drei Commits: Inhalt,
`git mv`, Haekchen — das folgt aus der Hard Rule, es widerspricht ihr nicht. -->

Regeln dieser Sektion: Baseline-Regelwerk `modul-06-roadmap.md`
§Das Beobachtungs-Register (vorhandene `BEO-<NNN>` **zitieren** statt neu
formulieren — sonst zählt das Register zwei Namen getrennt) ·
`grundlagen-traceability.md` §Herkunfts-Anker für Steering-Loop-Regeln (das
Feld `liegt in` steht **nur**, wenn mit diesem Slice wirklich etwas verkörpert
wurde; Feld und Zielort auf **einer** Zeile, Sektionsangabe innerhalb der
Backticks).

- **Was hat funktioniert:** Der Implementer stellte die eigene Design-
  Entscheidung (globaler `slog`-Singleton) selbst zur Prüfung, statt sie
  zu verschweigen — allerdings gegen die falsche ADR (0026 statt 0024).
  Der Review-Fund (F-1, HIGH) ging über die Architect-Sequenz statt
  über eine Herabstufung durch den Reviewer; der Architect löste die
  Kernfrage mit vier unabhängigen Text-Belegen aus
  [`ADR-0024`](../../../../docs/plan/adr/README.md)
  (Bezug-Feld, Kontext, Entscheidungssatz, Schärft-Kette zu
  [`ARC-011`](../../../../spec/architecture.md)). Der
  anschließende Fix-Zug lieferte eine saubere Port-Abstraktion
  (`LogPort` + `SlogAdapter`) **vollständig in einem Lauf** — keine
  Rückführung nötig, obwohl sie realistisch drohte (Port-Definition +
  Driven-Adapter + Bootstrap-Neuverdrahtung + sechs Aufrufstellen).
- **Was ging anders als geplant:** Der ursprüngliche §3-Plan sah keinen
  neuen Port vor (reine `slog`-Verdrahtung war die ursprüngliche
  Annahme) — der Fix-Zug fügte `internal/application/port/outbound/log.go`
  und `internal/adapters/driven/telemetry/` neu hinzu, sauber im
  Plan-Nachzug getragen. Ein Verifier-Fund (V-1, LOW: Mutationsproben-
  Lücke durch eine Go-Zero-Value-Koinzidenz im Level-Filter-Test) wurde
  in einer letzten Fixrunde geschlossen, mit echter Mutationsprobe
  (rot bei der zuvor unentdeckten Mutation, dann wieder grün).
- **Steering-Loop-Eintrag:** nichts verkörpert — der Normalfall.
- **Beobachtungs-Register (`../observations/`):** keine Beobachtung
  angefallen.
- **Folge-Slices:** keine.
- **Risiken aus §6:** (a) entfallen (geprüft, kein Rest im Scope).
- **Drei Paarungen:** entfällt hier — das Repo arbeitet mit Wellen; die
  Welle-4-Closure prüft Anker · Folge-Slice · Register auch für diesen
  Slice.

## 8. Sub-Area-Prüfungen und Modus-Begründung

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Ziel-Form: Sub-Area-Modus-Begründung — dort die **zwei vorgelagerten
Schritte** (sie stehen in jedem Slice-Plan, unabhängig von Modus und
Slice-Typ) und die **vier Pflichtkriterien** (Konventionen-Dichte ·
Phase-Reife · Evidenz-/Diskrepanz-Risiko · Reconciliation-Aufwand), vier und
nicht mehr.

**Der Abschnitt selbst entfällt nie.** Die zwei vorgelagerten Prüfungen laufen
in **jedem** Slice-Plan — sie hängen weder am Modus noch am Slice-Typ. Bedingt
ist allein der Modus-Begründungsblock am Ende; deshalb nennt der Titel beide
Hälften.

**Vorgelagert — Sub-Area-Wahl prüfen:** Die berührte Sub-Area (Bootstrap,
Driven-Adapter, Driving-Adapter) ist ein Segment des GF-Baums der
Modus-Deklaration (`PGC` Greenfield, Doc führt) — erfüllt die Schwelle
≥ 2 von 3 Achsen. Nicht zu grob.

**Vorgelagert — offene Beobachtungen sichten:** Register gelesen (neun
Einträge zum Zeitpunkt der Planung): keiner der neun Einträge betrifft
Logging — keine Treffer.

**Modus-Begründungsblock — Umfang.** Reiner GF-Hinweis genügt (siehe oben);
kein Sub-Area-Block.
