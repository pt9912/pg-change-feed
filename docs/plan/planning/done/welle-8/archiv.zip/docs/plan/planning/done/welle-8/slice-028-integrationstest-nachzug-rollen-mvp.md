# Slice slice-028: Compose-Integrationstest-Nachzug — Rollen-DSN-Trennung, MVP-Umbenennung

**Lifecycle:** Der Zustand dieses Slice ist das Verzeichnis, in dem diese
Datei liegt — eines von `open/`, `next/`, `in-progress/`, `done/`. Er
wechselt nur durch `git mv`, siehe
Baseline-Regelwerk `modul-05-planning-harness.md` §Lifecycle als State Machine.

**Welle:** [`welle-8`](welle-8.md) — der Nachweis, dass der
Compose-Integrationstest alle seit `welle-3` hinzugekommenen
post-MVP-Fähigkeiten zusammen abdeckt, ist welle-8s Closure-Trigger (§3),
kein Einzel-Slice-DoD.

**Bezug:** [`LH-QA-SEC-001`](../../../../spec/lastenheft.md)…`003`
(Least-Privilege, getrennte Berechtigbarkeit, Beschränkbarkeit von
CDC-Datenzugriffen) — dieser Slice erweitert die Testabdeckung für einen
bestehenden Vertrag (`ADR-0047`, bereits `slice-023` umgesetzt), ändert ihn
nicht. Kein aktives ADR wird geändert.

**Berührte Spec-Stellen:** — (reine Testinfrastruktur und
Dokumentations-/Namenskorrektur, keine Verhaltensänderung an einer
Spec-Stelle).
Der Verweis zeigt **aufwärts**: Die Spec nennt diesen Slice nie
(Baseline-Regelwerk `grundlagen-referenz-richtung.md`
§Referenz-Richtung (SDP), `grundlagen-source-precedence.md` §ID-Schema als Klammer).

**Verantwortlich:** pt9912.

**Autor:** pt9912. **Datum:** 2026-09-12.

---

## 1. Ziel und Abgrenzung

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Ziel-Form: Slice — Schnitt nach Lieferwert, nicht nach Schichten; jeder Slice
ist einzeln lieferbar. **§1 nennt Ziel und Abgrenzung** (Out-of-Scope-Disziplin
des Lastenhefts, auf den Slice-Plan angewandt); die vier Klassen des
Ausschlusses stehen in **eben diesem Abschnitt** des Baseline-Regelwerks,
zusammen mit der Begründungs-Pflicht je Punkt.

**Ziel:** Der Compose-Integrationstest verifiziert real, dass die seit
`slice-023` verdrahtete rollen-spezifische DSN-Trennung
(`cdc_capture`/`cdc_admin`/`cdc_reader`, `ADR-0047`) auf PostgreSQL-Ebene
greift — angestrebt war, damit `BEO-PGC/rollen-test-abdeckungsluecken`
Punkt (2) zu schließen (Replication-Stream- und ACK-Adapter,
`cdc_capture`-gebunden, gegen Rollen-Vertauschung testgesichert); real
erreicht wurde nur die PostgreSQL-Ebene, nicht die Adapter-Ebene — siehe
§2 DoD und §7 Closure-Notiz für die tatsächliche Deckung. Zusätzlich: `make test-integration`
([`tools/harness/run-integration-tests.sh`](../../../../tools/harness/run-integration-tests.sh))
und `test/integration/mvp_test.go` werden umbenannt, sobald ihr Scope die
Bezeichnung „MVP" nicht mehr korrekt trägt.

**Ausdrücklich NICHT in diesem Slice** — je Punkt mit Begründung:

- **`BEO-PGC/rollen-test-abdeckungsluecken` Punkt (1)** (Heartbeat-Grant-Test
  liest nie den tatsächlichen `nacharbeit-roles.sql`-Inhalt) — Bestand
  bleibt bewusst stehen: anderer Vorgang, betrifft einen bestehenden
  Unit-/Adapter-Test (`internal/bootstrap/roles_wiring_test.go`), keine
  neue Compose-Integrationstest-Abdeckung.
- **Neue Rollen oder DDL-Änderungen** — Bestand bleibt bewusst stehen: Die
  drei Rollen existieren bereits (`slice-011`, `slice-023`) und werden nur
  *geprüft*, nicht neu geschnitten.
- **Black-Box-CLI-Aufrufmuster neu erfinden** — Folge-Slice `slice-027`
  liefert das bereits; dieser Slice nutzt es, wo es für die
  Rollen-Verifikation passt (z. B. ein CLI-Aufruf mit absichtlich falscher
  Rolle), erfindet aber kein zweites Muster.
- **WAL-Rückstand-Schwellen-Verhalten zusätzlich gegen den Compose-Stack
  prüfen** — Bestand bleibt bewusst stehen: bereits real gegen PostgreSQL
  bewiesen (`slice-026`, welle-8 §6 Out-of-Scope).

**Keine Mindestzahl.** Ein Slice mit *einem* echten Ausschluss ist besser als
einer mit vier erfundenen; die vier Klassen sind ein Suchraster, keine
Ausfüll-Liste. Suchreihenfolge: Was übernimmt ein **Folge-Slice** (mit
Kennung — und die Kennung muss den Punkt auch annehmen)? Was bleibt als
**Bestand** bewusst stehen (mit Begründung)? Was wäre ein **anderer Vorgang**?
Welche **Schicht** rührt der Slice nicht an?

Was hier steht, ist die Grenze, an der ein wachsender Slice sich messen lässt:
Wer später etwas mitnimmt, das hier ausgeschlossen war, hat den Plan
**geändert**, nicht nur ergänzt.

## 2. Definition of Done

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Ziel-Form: Slice — **≤ 3 Liefer-Punkte**; mehr heißt: der Slice ist zu groß und
gehört zurück zur Zerlegung. Gezählt wird nur, was mit dem Umfang wächst — die
Gate-Läufe und die fünf Closure-Pflichten darunter zählen nicht mit.

- [x] `LH-QA-SEC-001`…`003` **teilweise** erfüllt — **Planner-Korrektur nach
      Reviewer-Fund F-1** ([`review-slice-028.md`](../../../reviews/review-slice-028.md)):
      Der Compose-Integrationstest belegt real PostgreSQLs serverseitige
      Durchsetzung des `REPLICATION`-Attributs (Schreib-Ablehnung für
      `cdc_reader`, Verbindungs-Ablehnung ohne `REPLICATION`-Attribut,
      Erfolg mit) — über eigens angelegte, ephemere Login-Identitäten per
      rohem `psql`. Er ruft **nicht** die tatsächlichen Replication-Stream-/
      ACK-Adapter (`receive.NewStream`/`postgresack.New`) auf und bleibt vom
      laufenden Feed-Container entkoppelt (der ohnehin mit Superuser-DSNs
      verdrahtet ist, `BEO`/Review zu `slice-023` INFO-1, unverändert seit
      `slice-023`). Er schließt `BEO-PGC/rollen-test-abdeckungsluecken`
      Punkt (2) damit **nicht vollständig** — nur die PostgreSQL-Ebene der
      Rollentrennung, nicht die Adapter-Ebene. Beleg:
      `tools/harness/run-integration-tests.sh` (Abschnitt
      „Rollen-DSN-Verifikation gegen den Compose-Stack"), Commit `ba508ed`;
      dreimal in Folge grün gegen den realen Compose-Stack.
- [x] `mvp_test.go` benannt nach tatsächlichem Scope (der Make-**Target**-Name
      `test-integration` bleibt unverändert — er ist bereits scope-neutral,
      nur der Datei- und Helptext-Name trägt „MVP"), und der
      Makefile-Helptext (`## MVP-Integrationstest …`) sowie
      `harness/README.md`/`AGENTS.md`-Erwähnungen entsprechend nachgezogen,
      sobald der tatsächliche Scope (Consumer-Zugriffsweg,
      Rollen-DSN-Trennung, plus der bereits bestehende
      `cdc_capture_lag`-Lasttest-Beleg) die Bezeichnung „MVP" nicht mehr
      korrekt trägt. Beleg: `git mv` Commit `632ddca`
      (`test/integration/integration_test.go`), Inhalts-/Doku-Nachzug
      Commit `9a84407` (Makefile, `harness/README.md`,
      `integration_test.go`-Kommentare, `run-integration-tests.sh`,
      `welle-8.md`-Kreuzverweis). `AGENTS.md` trug keine „MVP"-Erwähnung —
      kein Änderungsbedarf dort.
- [x] `make gates` grün, `make test-integration` dreimal in Folge grün.
      Beleg: lokaler Lauf am HEAD (`632ddca`/`ba508ed`/`9a84407`), je
      dreimal in Folge grün — siehe Implementer-Bericht.
- [x] Review durchgeführt, Report unter `docs/reviews/` liegt vor
      (`.harness/skills/reviewer.md`) — Rollenwechsel nach Schritt 8 des
      Minimal Agent Workflow (`AGENTS.md` §6), kein Self-Review (Modul 8).
      Beleg: [`docs/reviews/review-slice-028.md`](../../../reviews/review-slice-028.md)
      (1 MEDIUM F-1 — DoD-Überzeichnung, oben per Planner-Korrektur behoben;
      1 INFO F-2 — Superuser-Verdrahtung real bestätigt, aber unverändert
      seit `slice-023` (Review zu `slice-023` INFO-1), keine Eskalation
      gerechtfertigt), unabhängig bestätigt durch
      [`docs/reviews/verify-slice-028.md`](../../../reviews/verify-slice-028.md)
      (Planner-Korrektur als akkurat bestätigt, 2× LOW V-1/V-2, siehe §7).
- [x] Doku-Update für `harness/README.md`/`AGENTS.md` (Sensors-Tabelle,
      Target-Name und -Beschreibung nach der Umbenennung). Beleg: siehe
      oben, Commit `9a84407`.
- [x] Closure-Notiz mit Steering-Loop-Lerneintrag.
- [x] Reconciliation-Register (`../reconciliation.md`) fortgeschrieben, **falls dieser Slice einen Inventur-Fund auflöst** — Zeile mit Datum und auflösendem Artefakt nach *Aufgelöste Einträge* verschoben. Repos ohne Brownfield-Bootstrap haben die Datei nicht; dann entfällt das Item. Entfällt: Repo ist Greenfield (`harness/conventions.md` §Modus-Deklaration), `../reconciliation.md` existiert nicht.
- [x] Beobachtungs-Register (`../observations/`) fortgeschrieben — neues Verzeichnis `BEO-<KUERZEL>/<slug>/` oder eine weitere Datei in dessen `evidence/`; **kein Zaehler wird gesetzt**, er folgt aus den Dateien. Keine Beobachtung angefallen ist ebenfalls eine Antwort und wird in §7 notiert.
      `evidence/slice-028.md` in `BEO-PGC/rollen-test-abdeckungsluecken/`
      ergänzt — Zähler steht bei 2×, beide Punkte (1) und (2) bleiben
      `weiter offen`.
- [x] Jedes Risiko aus §6 trägt einen Ausgang (eingetreten / entfallen / weiter offen).
- [ ] Die drei Paarungen (Anker · Folge-Slice · Register) sind getragen — im Repo **ohne** Wellen-Betrieb hier geprüft, im Repo **mit** Wellen von der nächsten Welle-Closure (auch für Slices ohne Wellen-Zugehörigkeit). Entfällt hier: Repo mit Wellen-Betrieb — Prüfung läuft bei der `welle-8`-Closure.

## 3. Plan (vor Code)

Regeln dieser Sektion: Baseline-Regelwerk `grundlagen-bootstrap.md`
§Was ist eine Sub-Area? — diese Liste liefert die **Pfad-Kandidaten** für §8,
nicht die Antwort: Pfad-Berührung ist nicht hinreichend, und eine
Aussagen-Berührung steht hier gar nicht.

| Datei / Komponente | Änderungs-Art | Begründung |
|---|---|---|
| `tools/harness/run-integration-tests.sh` | update | neuer Abschnitt: Zugriff mit falscher Rolle (z. B. `cdc_reader`-DSN für einen schreibenden Aufruf) real gegen den Compose-Stack zurückgewiesen |
| `tools/harness/run-replication-tests.sh` oder Äquivalent | update | rollenbeschränkte Login-Test-Identität für den Replication-Stream-/ACK-Rollen-Vertauschungstest (`BEO-PGC/rollen-test-abdeckungsluecken` Punkt 2) |
| `test/integration/mvp_test.go` → neuer Dateiname | rename+update | Umbenennung nach tatsächlichem Scope |
| `Makefile` | update | Helptext-Zeile für `test-integration` (Target-Name bleibt) |
| `harness/README.md`, `AGENTS.md` | update | Sensors-Tabelle/Erwähnungen nach der Umbenennung nachgezogen |

**Plan-Nachzug (Abweichungen, nach Bestandsprüfung entschieden — §Bestand
lesen, Schritt 1 der Aufgabe):**

- **`tools/harness/run-replication-tests.sh` bleibt unverändert.** Die
  Compose-PostgreSQL-Instanz trägt die drei Gruppenrollen bereits real
  (`make schema-rollout` rollt `nacharbeit-roles.sql` auch dort aus, vor
  dem Feed-Container-Start) — anders als angenommen brauchte die
  Rollen-Vertauschungsprüfung für Replication-Stream/ACK deshalb keine
  Erweiterung der `wal_level=logical`-Testcontainer-Kette
  (`run-replication-tests.sh`), sondern ließ sich vollständig gegen die
  ohnehin laufende Compose-Instanz in `run-integration-tests.sh`
  umsetzen — empirisch mit einem Scratch-Postgres desselben Digest-Pins
  verifiziert, bevor die Änderung in den Runner ging (kein Rätselraten
  über `pg_hba.conf`-Verhalten oder REPLICATION-Attribut-Vererbung).
  Näher an `ADR-0047` Kontext-Befund 2 (Attribut wird nicht über
  Mitgliedschaft vererbt) und ohne die Testpyramide-Schicht zu wechseln.
- **`docs/plan/planning/welle-8.md`** zusätzlich angefasst (nicht in der
  ursprünglichen Plan-Tabelle): ein Dateipfad-Kreuzverweis auf
  `test/integration/mvp_test.go` in §1 wäre nach der Umbenennung
  veraltet gewesen.

## 4. Trigger

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Trigger je Lifecycle-Übergang und WIP-Limit.

**Start** (`next` → `in-progress`): `slice-027` liegt in `done/` (liefert
das Black-Box-CLI-Aufrufmuster, das dieser Slice für die
Rollen-Verifikation mitnutzt) — Priorisiert, `Verantwortlich:` gesetzt,
WIP-Limit (1 je Implementer) frei.

**Rückführungen — vorab benennen, nicht erst im Nachhinein begründen:**

- `in-progress` → `next` (zu groß, zurück zur Zerlegung): Zeigt sich, dass
  die Rollen-Verifikation für Replication-Stream/ACK eine grundlegende
  Änderung an `run-replication-tests.sh`s Verbindungsaufbau braucht (mehr
  als eine Schicht), gehört das zurück zur Zerlegung.
- `in-progress` → `open` (blockiert — Carveout?): `slice-027` ist noch
  nicht `done`.

## 5. Closure-Trigger

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Closure- und Lerneintrag-Regeln — zwei beobachtbare Kriterien **und** ein
Lerneintrag; ohne ihn ist der Slice nur abgelegt.

DoD vollständig **und** `make gates` grün **und** `make test-integration`
dreimal in Folge grün **und** Closure-Notiz geschrieben (inkl.
`BEO-PGC/rollen-test-abdeckungsluecken` Punkt-(2)-Fortschritt).

## 6. Risiken und offene Punkte

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Offene Risiken werden bei Closure aufgelöst — **jedes** Risiko bekommt genau
**einen** Ausgang, und kein Slice geht nach `done/`, während eines ohne Ausgang
dasteht.

- Rollenbeschränkte Login-Test-Identitäten für den Replication-Stream
  könnten zusätzliche PostgreSQL-Rollen-Berechtigungen brauchen, die
  `ADR-0047`s Rollenmodell nicht vorsieht — das wäre eine Architect-Frage,
  keine reine Testinfrastruktur-Änderung. **Ausgang: entfallen** — der
  Implementer fand einen einfacheren Weg (Prüfung direkt gegen die
  Compose-Instanz statt gegen die `wal_level=logical`-Testcontainer-Kette),
  der ohne neue Rollen-Berechtigungen auskam; die Frage stellte sich nicht.
- Die Umbenennung von `mvp_test.go`/Helptext könnte weitere, hier nicht
  erfasste Erwähnungen von „MVP-Integrationstest" im Repo übersehen (z. B.
  in älteren Closure-Notizen — die bleiben unangetastet, da sie Historie
  sind, aber laufende Doku könnte betroffen sein). **Ausgang: entfallen** —
  Implementer und Reviewer bestätigten unabhängig, dass alle laufenden
  Doku-Stellen (`Makefile`, `harness/README.md`, `run-integration-tests.sh`,
  `welle-8.md`) nachgezogen wurden; verbleibende Erwähnungen liegen nur in
  bereits abgeschlossenen `done/`-Closure-Notizen (Historie, bewusst
  unangetastet).
- **Neues Risiko, aus Reviewer-Fund F-1:** `BEO-PGC/rollen-test-abdeckungsluecken`
  Punkt (2) ist nur auf PostgreSQL-Ebene geschlossen, nicht auf
  Adapter-Ebene (`receive.NewStream`/`postgresack.New` werden nie mit
  rollenbeschränkten Verbindungen aufgerufen). **Ausgang: weiter offen** →
  bleibt in `BEO-PGC/rollen-test-abdeckungsluecken` (Zähler 2×, Punkt (2)
  weiterhin nicht vollständig geschlossen).

## 7. Closure-Notiz

<!-- BEDIENHINWEIS — keine Norm; faellt beim Kopieren weg (README.md
§Verwendung, Schritt 5) und darf deshalb nichts Tragendes halten. Reihenfolge:
diese Sektion vor dem `git mv` nach done/ fuellen — einzige Ausnahme ist das
letzte DoD-Item in §2 (die Paarungen suchen in `done/`, also nach dem `git mv`).
Im Repo ohne Wellen-Betrieb braucht die Closure dadurch drei Commits: Inhalt,
`git mv`, Haekchen — das folgt aus der Hard Rule, es widerspricht ihr nicht. -->

Regeln dieser Sektion: Baseline-Regelwerk `modul-06-roadmap.md`
§Das Beobachtungs-Register (vorhandene `BEO-<NNN>` **zitieren** statt neu
formulieren — sonst zählt das Register zwei Namen getrennt) ·
`grundlagen-traceability.md` §Herkunfts-Anker für Steering-Loop-Regeln (das
Feld `liegt in` steht **nur**, wenn mit diesem Slice wirklich etwas verkörpert
wurde; Feld und Zielort auf **einer** Zeile, Sektionsangabe innerhalb der
Backticks).

- **Was hat funktioniert:** Der Implementer verifizierte seine eigene
  Plan-Annahme empirisch (Scratch-Postgres mit demselben Digest-Pin), bevor
  er sie in den Runner übernahm — das ersparte eine unnötige Erweiterung
  von `run-replication-tests.sh` und hielt den Slice klein. Reviewer und
  Verifier haben unabhängig voneinander dieselbe Grenze gefunden
  (Adapter-Ebene fehlt) und unabhängig dieselbe Einordnung der
  Superuser-Verdrahtung als „vorbestehend, keine Regression" getroffen —
  zwei unabhängige Kontexte, dieselbe Schlussfolgerung.
- **Was ging anders als geplant:** Der DoD-Text behauptete zunächst, dieser
  Slice schließe `BEO-PGC/rollen-test-abdeckungsluecken` Punkt (2)
  vollständig. Der Reviewer fand das zu stark formuliert (F-1) — die
  Rollen-Verifikation deckt nur die PostgreSQL-Server-Ebene ab, nicht die
  tatsächlichen Replication-Stream-/ACK-Adapter. Als Planner habe ich die
  DoD-Zeile, §1 und §6 korrigiert; der Verifier bestätigte die Korrektur
  unabhängig als akkurat. Konsequenz: Punkt (2) bleibt im Register offen,
  keine stillschweigende Schließung einer nicht wirklich erfüllten Zusage.
- **Steering-Loop-Eintrag:** Kein Eintrag erreicht mit diesem Slice 3× und
  wird verkörpert — der Normalfall. Die vom Verifier notierten
  DoD-Checkbox-Lücken (V-1, V-2) sind dieselbe strukturelle Klasse wie bei
  `slice-024`…`027`.
- **Beobachtungs-Register (`../observations/`):** `evidence/slice-028.md`
  in `BEO-PGC/rollen-test-abdeckungsluecken/` ergänzt — Zähler steht bei
  2×, beide Punkte (1) und (2) bleiben `weiter offen`. Keine neue
  Beobachtung angefallen.
- **Folge-Slices:** keine neuen — die Adapter-Ebenen-Lücke bleibt im
  Register; ein Folge-Slice entsteht erst, falls sie 3× erreicht oder ein
  Nutzer sie gezielt einplant.
- **Risiken aus §6:** zwei *entfallen* (rollenbeschränkte Login-Identitäten
  brauchten keine neuen Berechtigungen; MVP-Umbenennung vollständig
  nachgezogen), ein neues Risiko (Adapter-Ebenen-Lücke) *weiter offen* →
  `BEO-PGC/rollen-test-abdeckungsluecken`.
- **Drei Paarungen:** Repo **mit** Wellen-Betrieb (`welle-8` offen) —
  verschoben auf die welle-8-Closure (Modul 8 §Rollen-Sequenz für eine
  Welle).

## 8. Sub-Area-Prüfungen und Modus-Begründung

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Ziel-Form: Sub-Area-Modus-Begründung — dort die **zwei vorgelagerten
Schritte** (sie stehen in jedem Slice-Plan, unabhängig von Modus und
Slice-Typ) und die **vier Pflichtkriterien** (Konventionen-Dichte ·
Phase-Reife · Evidenz-/Diskrepanz-Risiko · Reconciliation-Aufwand), vier und
nicht mehr.

**Der Abschnitt selbst entfällt nie.** Die zwei vorgelagerten Prüfungen laufen
in **jedem** Slice-Plan — sie hängen weder am Modus noch am Slice-Typ. Bedingt
ist allein der Modus-Begründungsblock am Ende; deshalb nennt der Titel beide
Hälften.

**Vorgelagert — Sub-Area-Wahl prüfen:** Einzige berührte Sub-Area ist die
Repo-weite Default-Sub-Area `*`/`PGC`.

**Vorgelagert — offene Beobachtungen sichten:** Register durchgegangen.
Treffer für `PGC`: `BEO-PGC/rollen-test-abdeckungsluecken` (1×, weiter
offen — dieser Slice schließt Punkt (2) davon),
`BEO-PGC/test-isolation-geteilter-zustand` (1×, nicht einschlägig — anderer
Test-Layer, siehe welle-8 §6 Out-of-Scope). Keiner der Treffer erreicht mit
diesem Slice 3×.

**Modus-Begründungsblock — Umfang.** Pflicht, sobald mindestens eine berührte
Sub-Area BF oder Hybrid ist — einer pro Sub-Area. Bei reinem GF genügt der
Hinweis *"alle berührten Sub-Areas GF"*; bei reinem Refactor ohne neue
Sub-Area-Berührung entfällt **er** — nicht der Abschnitt.

Alle berührten Sub-Areas GF (nur `*`/`PGC`).
