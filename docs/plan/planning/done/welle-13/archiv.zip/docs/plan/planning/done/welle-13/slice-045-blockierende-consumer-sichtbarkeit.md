# Slice slice-045: Sichtbarkeit blockierender Consumer

**Lifecycle:** Der Zustand dieses Slice ist das Verzeichnis, in dem diese
Datei liegt — eines von `open/`, `next/`, `in-progress/`, `done/`. Er
wechselt nur durch `git mv`, siehe
Baseline-Regelwerk `modul-05-planning-harness.md` §Lifecycle als State Machine.

**Welle:** welle-13 — dritter Slice, unabhängig von `slice-043`/`044`
(reine Observability auf bestehendem `cdc.consumer_status`-Zustand).

**Bezug:** [`LH-FA-RET-005`](../../../../spec/lastenheft.md).

**Berührte Spec-Stellen:** — (reine SQL-View-/CLI-Ergänzung auf
bestehenden Daten, keine neue Architektur-Sicht-Aussage).

**Verantwortlich:** pt9912.

**Autor:** pt9912. **Datum:** 2026-09-13.

---

## 1. Ziel und Abgrenzung

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Ziel-Form: Slice — Schnitt nach Lieferwert, nicht nach Schichten; jeder Slice
ist einzeln lieferbar. **§1 nennt Ziel und Abgrenzung** (Out-of-Scope-Disziplin
des Lastenhefts, auf den Slice-Plan angewandt); die vier Klassen des
Ausschlusses stehen in **eben diesem Abschnitt** des Baseline-Regelwerks,
zusammen mit der Begründungs-Pflicht je Punkt.

**Ziel:** Eine neue SQL-Lese-View (z. B. `cdc.retention_blockers`,
Implementer entscheidet den Namen und begründet ihn im Plan-Nachzug)
zeigt je Quelle den am weitesten zurückliegenden unbestätigten Consumer
— Name, Position, Rückstand zur letzten Commit-Position — also genau
den Consumer, dessen Position `RetentionPolicy.AllowsDeletion`
(`slice-043`) aktuell blockiert (`LH-FA-RET-004.a`s „Safe Watermark"
sichtbar gemacht, nicht neu berechnet). Der bestehende `diagnose`-
CLI-Befehl (`slice-038`) bekommt optional dieselbe Information
ergänzt, falls das ohne Bruch des bestehenden Ausgabeformats möglich
ist (Implementer-Entscheidung, siehe Plan-Nachzug).

**Ausdrücklich NICHT in diesem Slice** — je Punkt mit Begründung:

- **Neue Berechnung des Safe Watermark** — `LH-FA-RET-004.a` beschreibt
  das Verfahren bereits vollständig, `slice-043`s
  `RunRetentionUseCase` implementiert es; dieser Slice macht das
  Ergebnis nur sichtbar, berechnet es nicht neu (keine Duplikat-Logik
  zwischen SQL-View und Go-Code).
- **Automatische Warnung/Alarmierung bei blockierenden Consumern** (z. B.
  über die `diagnose`-Fehlerzustand-Klasse) — ein anderer Vorgang mit
  eigenem Schwellenwert-Bedarf (`AGENTS.md` §3.6, ADR-pflichtig), hier
  nicht angefragt.
- **Löschausführung selbst** — `slice-043`/`044`; dieser Slice ist reine
  Observability auf bereits vorhandenem Zustand.

**Keine Mindestzahl.** Ein Slice mit *einem* echten Ausschluss ist besser als
einer mit vier erfundenen; die vier Klassen sind ein Suchraster, keine
Ausfüll-Liste. Suchreihenfolge: Was übernimmt ein **Folge-Slice** (mit
Kennung — und die Kennung muss den Punkt auch annehmen)? Was bleibt als
**Bestand** bewusst stehen (mit Begründung)? Was wäre ein **anderer Vorgang**?
Welche **Schicht** rührt der Slice nicht an?

Was hier steht, ist die Grenze, an der ein wachsender Slice sich messen lässt:
Wer später etwas mitnimmt, das hier ausgeschlossen war, hat den Plan
**geändert**, nicht nur ergänzt.

## 2. Definition of Done

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Ziel-Form: Slice — **≤ 3 Liefer-Punkte**; mehr heißt: der Slice ist zu groß und
gehört zurück zur Zerlegung. Gezählt wird nur, was mit dem Umfang wächst — die
Gate-Läufe und die fünf Closure-Pflichten darunter zählen nicht mit.

- [x] Neue SQL-View zeigt je Quelle real den am weitesten
      zurückliegenden unbestätigten Consumer (Name, Position,
      Rückstand) — real gegen mindestens zwei Consumer getestet
      (einer blockiert, einer nicht). `cdc.retention_blockers`
      (`tools/schema/schema.yaml`), siehe Plan-Nachzug Punkt 1.
- [x] `LH-FA-RET-005` real erfüllt: ein Integrationstest liest die neue
      View über SQL (analog zum bestehenden `cdc.active_tables`-/
      `cdc.consumer_status`-Testmuster aus `welle-11`).
      `TestMVPRetentionBlockersViewShowsFurthestBehindConsumer`
      (`test/integration/integration_test.go`), real grün über
      `make test-integration`; die Rollen-Beschränkung (`cdc_reader`)
      zusätzlich real über `make test-store`
      (`TestCdcReaderRoleReadsViewsNotBaseTables`, siehe Plan-Nachzug
      Punkt 4).
- [x] `make gates` grün, `make test-integration` grün. Beide real
      ausgeführt (Ausgaben im Implementer-Bericht); zusätzlich
      `make test-store` real grün (Rollen-Grant-Beleg).
- [x] Review durchgeführt, Report unter `docs/reviews/` liegt vor
      (`.harness/skills/reviewer.md`) — Rollenwechsel nach Schritt 8 des
      Minimal Agent Workflow (`AGENTS.md` §6), kein Self-Review (Modul 8).
      Beleg: [`docs/reviews/review-slice-045.md`](../../../reviews/review-slice-045.md)
      (0 HIGH/MEDIUM/LOW, 1 INFO — kein Fixrunden-Bedarf). Verifikation in
      [`docs/reviews/verify-slice-045.md`](../../../reviews/verify-slice-045.md)
      (DoD eigenständig nachgeprüft, keine Rückführung nötig).
- [x] Doku-Update: `docs/user/benutzerhandbuch.md` nennt die neue View
      (analog zu „Aktivierte Tabellen auflisten"). Neuer Abschnitt
      „Blockierende Consumer erkennen" unter „Aufbewahrung (Retention)",
      plus `cdc_reader`-Zeile in der Rollen-Tabelle ergänzt.
- [x] Closure-Notiz mit Steering-Loop-Lerneintrag. Siehe §7.
- [x] Reconciliation-Register (`../reconciliation.md`) fortgeschrieben, **falls dieser Slice einen Inventur-Fund auflöst** — Zeile mit Datum und auflösendem Artefakt nach *Aufgelöste Einträge* verschoben. Repos ohne Brownfield-Bootstrap haben die Datei nicht; dann entfällt das Item. Entfällt: Repo ist Greenfield, `../reconciliation.md` existiert nicht.
- [x] Beobachtungs-Register (`../observations/`) fortgeschrieben — neues Verzeichnis `BEO-<KUERZEL>/<slug>/` oder eine weitere Datei in dessen `evidence/`; **kein Zaehler wird gesetzt**, er folgt aus den Dateien. Keine Beobachtung angefallen ist ebenfalls eine Antwort und wird in §7 notiert. Siehe §7.
- [x] Jedes Risiko aus §6 trägt einen Ausgang (eingetreten / entfallen / weiter offen). Siehe §6 — beide entfallen.
- [ ] Die drei Paarungen (Anker · Folge-Slice · Register) sind getragen — im Repo **ohne** Wellen-Betrieb hier geprüft, im Repo **mit** Wellen von der nächsten Welle-Closure (auch für Slices ohne Wellen-Zugehörigkeit). Repo mit Wellen-Betrieb (`welle-13` offen) — Prüfung läuft bei der `welle-13`-Closure.

## 3. Plan (vor Code)

Regeln dieser Sektion: Baseline-Regelwerk `grundlagen-bootstrap.md`
§Was ist eine Sub-Area? — diese Liste liefert die **Pfad-Kandidaten** für §8,
nicht die Antwort: Pfad-Berührung ist nicht hinreichend, und eine
Aussagen-Berührung steht hier gar nicht.

| Datei / Komponente | Änderungs-Art | Begründung |
|---|---|---|
| `tools/schema/schema.yaml` | update | neue View im `views:`-Knoten (deklarativ, wie `active_tables`/`consumer_status`) |
| `test/integration/integration_test.go` | neu/update | Testfall gegen die neue View |
| `docs/user/benutzerhandbuch.md` | update | neue View dokumentiert |

### Plan-Nachzug (nach Implementierung)

Regeln dieser Sektion: Implementierungsentscheidungen, die über die Tabelle
oben hinausgehen — Name/Form der View, die CLI-Entscheidung und die
Behandlung des „Consumer nie bestätigt"-Randfalls.

**1. Name/Form: `cdc.retention_blockers`, eine Zeile je Quelle über
`DISTINCT ON`.** Die View liest `cdc.consumer_position` (INNER JOIN
`cdc.consumer`, keine Basistabelle direkt aus Go-Code oder Domain-Logik
neu ausgewertet) und wählt je `source_id` deterministisch den Consumer mit
der kleinsten `acknowledged_position` — das ist exakt die Position, die
`RetentionPolicy.AllowsDeletion` (`slice-043`) als bindende Untergrenze
behandelt, weil eine Freigabe verlangt, dass **alle** übergebenen
Consumer-Positionen die Change-Position erreicht haben. `DISTINCT ON
(cp.source_id) ... ORDER BY cp.source_id, cp.acknowledged_position ASC,
c.consumer_id ASC` liefert höchstens eine Zeile je Quelle, mit
`consumer_id` als deterministischem Tie-Breaker bei mehreren Consumern auf
identischer Position (PostgreSQL-Dialekt-spezifisch, `source_dialect:
postgresql` ist bereits Pflicht für alle Views dieser Datei). `backlog`
berechnet `max(commit_position) - acknowledged_position` über eine
korrelierte Unterabfrage auf `cdc.transaction` — dasselbe Muster wie
`consumer_status.latest_commit_position`, keine neue Abfrageform.

**Verhältnis zu `cdc.consumer_status` (Architect-Verdikt,
`docs/reviews/architect-verdict-retention-loeschausfuehrung.md`, Frage 1):**
Das Verdikt notiert bereits, dass `consumer_status` „je Consumer" die
Rückstands-Information trägt und damit `LH-FA-RET-005`s Boundary („mehrere
blockierende Consumer ... alle einzeln erkennbar") bereits für **alle**
Consumer mit bestätigter Position abdeckt — unabhängig davon, ob sie
aktuell die Löschgrenze einer Quelle tragen. `cdc.retention_blockers`
dupliziert das nicht, sondern beantwortet die engere, im Ziel dieses
Slice-Plans benannte Frage: **welcher** Consumer je Quelle **aktuell**
die Freigabe blockiert (die für die Retention einzig entscheidende
Konsumenten-Position) — zwei verschiedene Fragen, zwei Sichten, keine
Redundanz.

**2. CLI-Erweiterung (`diagnose`) bewusst nicht vorgenommen.** Die DoD
dieses Slice zählt bereits drei Liefer-Punkte (View, Integrationstest,
Doku-Update) — die Größen-Obergrenze aus
`modul-05-planning-harness.md` §Ziel-Form: Slice. Eine vierte
Artefakt-Änderung an `internal/bootstrap/wiring.go` (`diagnose`-Ausgabe um
denselben Inhalt ergänzen) würde den Slice über diese Grenze heben, ohne
einen Informationsgewinn zu liefern, den der direkte SQL-Zugriff nicht
bereits trägt: `cdc.retention_blockers` ist über `CDC_READER_DSN`
(`cdc_reader`-Grant, siehe unten) genauso erreichbar wie jede andere
Lese-View, ohne den Feed-Container-Prozess oder sein stabiles
`diagnose`-Ausgabeformat zu berühren — ein Risiko, das
`run-integration-tests.sh`s bestehende Text-Assertions gegen die
`diagnose`-Ausgabe (`LH-FA-ADM-002`…`005`) sonst mittragen müssten. Die
CLI-Erweiterung bleibt damit ein **Bestand, der bewusst stehen bleibt**
(§1-Klasse „anderer Vorgang"): ein eigener Folge-Slice, falls ein
Betriebs-Bedarf für die Information *innerhalb* der `diagnose`-Ausgabe
entsteht, den der direkte SQL-Zugriff nicht deckt.

**3. „Consumer nie bestätigt"-Randfall (§6, Risiko 1) — dieselbe
Abwesenheits-Lesart wie `ConsumerStatePort.Positions`, keine neue
Sonderbehandlung nötig.** Die View liest ausschließlich
`cdc.consumer_position`-Zeilen (INNER JOIN, keine `LEFT JOIN` von
`cdc.consumer` wie bei `consumer_status`). Ein registrierter, aber gegen
eine Quelle noch nie bestätigender Consumer trägt keine Zeile in
`cdc.consumer_position` (`slice-043`s bereits etablierte
Abwesenheits-Lesart, `internal/application/port/outbound/consumerstate.go`
`Positions`-Doku) und erscheint deshalb **nicht** in
`cdc.retention_blockers` — weder fälschlich als „kein Blocker" (er wird
schlicht nicht betrachtet) noch mit einem irreführenden Wert. Das ist
konsistent mit dem, was `RunRetentionUseCase` real entscheidet: Ein
solcher Consumer blockiert auch die tatsächliche Löschausführung nicht
(`Positions` liefert ihn dort ebenfalls nicht zurück). Eine Quelle, für
die **kein** Consumer je bestätigt hat, trägt konsequent gar keine Zeile
in der View (kein aktueller Blocker) — dokumentiert in
`docs/user/benutzerhandbuch.md` §„Blockierende Consumer erkennen". Real
getestet: `TestMVPRetentionBlockersViewShowsFurthestBehindConsumer`
(`test/integration/integration_test.go`) registriert zwei Consumer direkt
über den `ConsumerStatePort`-Adapter (kein CLI-Rundlauf), bestätigt beide
auf unterschiedliche reale Positionen und belegt, dass ausschließlich der
weiter zurückliegende als Blocker erscheint — der bereits weiter
bestätigende Consumer erscheint nicht als Zeile.

**4. `cdc_reader`-Grant ergänzt (`tools/schema/nacharbeit-roles.sql`).**
Dieselbe View-Owner-Lese-Disziplin wie bei den drei bestehenden Views
(Definer-Semantik, kein Grant auf eine Basistabelle):
`GRANT SELECT ON cdc.active_tables, cdc.consumer_status, cdc.changes,
cdc.retention_blockers TO cdc_reader;` — ohne diese Ergänzung bliebe die
neue View für `CDC_READER_DSN` unerreichbar, obwohl sie dieselbe
Rollen-Klasse (Lese-View, `LH-QA-SEC-003`) trägt wie die drei
bestehenden. `CDC_INTEGRATION_DSN` (`test/integration`) verbindet nicht
als `cdc_reader`, sondern mit weiterreichenden Rechten — dieser Weg belegt
nur, dass die View selbst korrekt liest, nicht die Rollen-Beschränkung.
Die Rollen-Beschränkung selbst ist deshalb real über `make test-store`
geprüft: `TestCdcReaderRoleReadsViewsNotBaseTables`
(`internal/adapters/driven/postgresstorage/roles_test.go`) um eine
Zeile ergänzt, die nach `SET ROLE cdc_reader` ein `SELECT count(*) FROM
cdc.retention_blockers` real ausführt (Erfolg erwartet, Zeilenzahl 0 ist
in dieser Fixtur zulässig — geprüft wird die Zugriffserlaubnis, nicht der
Zeileninhalt) — dieselbe reale Rollenprüfung, die die Datei bereits für
`cdc.metrics` trägt.

**5. Realer Fund während der Implementierung — Testfall blockierte
dauerhaft die Retention-Löschausführung des Compose-Laufs, behoben durch
Cleanup im Testfall selbst.** `make test-integration` schlug in drei
aufeinanderfolgenden Läufen am bestehenden Retention-Beleg
(`tools/harness/run-integration-tests.sh`, aus `slice-044`) fehl:
`'RetentionOld' (id=200) wurde nach Freigabe durch beide Consumer nicht
innerhalb der Zeitspanne real entfernt`. Isoliert durch einen vierten Lauf
gegen den unveränderten `HEAD`-Stand (per `git stash`, ohne diesen
Slice-Diff) — dort lief derselbe Retention-Beleg real grün, also lag die
Ursache im eigenen Diff, nicht an Umgebungs-Flakiness. Ursache: Der neue
Testfall `TestMVPRetentionBlockersViewShowsFurthestBehindConsumer`
registrierte zwei eigene Consumer und bestätigte sie einmalig auf eine
frühe Position, ohne sie danach wieder zu entfernen — `Positions(mvpSource)`
(`ConsumerStatePort`, `slice-043`) liest **alle** bestätigten Positionen der
Quelle, unabhängig davon, welcher Testfall den Consumer angelegt hat; die
beiden liegen gebliebenen, nie fortgeschriebenen Positionen blockierten
danach `RetentionPolicy.AllowsDeletion` für den **gesamten** restlichen
Compose-Lauf — real derselbe Mechanismus, den dieser Slice sichtbar macht,
hier als selbst verursachter Störfall statt als Beobachtungsgegenstand.
Behoben: `t.Cleanup` entfernt beide Consumer über
`ConsumerStatePort.Remove` am Ende des Testfalls (Zeilen-Abwesenheit als
Rücknahme, dieselbe Lesart wie bei jeder administrativen Entfernung) —
danach lief `make test-integration` real grün, inklusive des bestehenden
Retention-Belegs. Kein Lerneintrag im Sinne einer Regel-/Sensor-Schärfung
(der Fehler war eine lokale Testfall-Hygiene-Lücke, kein wiederkehrendes
Muster über mehrere Slices), aber der Reihenfolge nach dokumentiert, weil
er über die ursprünglich geplante Implementierung hinausging und real
einen bestehenden Sensor rot gefärbt hätte, wäre er unentdeckt geblieben.

## 4. Trigger

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Trigger je Lifecycle-Übergang und WIP-Limit.

**Start** (`next` → `in-progress`): `welle-13` eröffnet,
`Verantwortlich:` gesetzt, WIP-Limit (1 je Implementer) frei —
unabhängig von `slice-043`/`044`.

**Rückführungen — vorab benennen, nicht erst im Nachhinein begründen:**

- `in-progress` → `next` (zu groß, zurück zur Zerlegung): Nicht zu
  erwarten bei einer reinen Lese-View auf bereits vorhandenem
  Zustand — falls doch, wäre das ein Zeichen für eine unerwartet
  komplexe Watermark-Berechnung, die eigentlich `slice-043` gehört.
- `in-progress` → `open` (blockiert — Carveout?): Kein bekannter Blocker.

## 5. Closure-Trigger

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Closure- und Lerneintrag-Regeln — zwei beobachtbare Kriterien **und** ein
Lerneintrag; ohne ihn ist der Slice nur abgelegt.

DoD vollständig **und** `make gates` grün **und** `make test-integration`
grün **und** Closure-Notiz geschrieben.

## 6. Risiken und offene Punkte

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Offene Risiken werden bei Closure aufgelöst — **jedes** Risiko bekommt genau
**einen** Ausgang, und kein Slice geht nach `done/`, während eines ohne Ausgang
dasteht.

- Ein Consumer ohne jede bestätigte Position (nie bestätigt) könnte die
  View entweder fälschlich als „kein Blocker" oder mit einem
  irreführenden Wert zeigen — dieselbe Klasse Randfall wie
  `slice-038`s §6 Risiko 2. **Ausgang: entfallen.** Die View liest
  `cdc.consumer_position` per `INNER JOIN` (keine `LEFT JOIN`) — ein nie
  bestätigender Consumer trägt strukturell keine Zeile und kann deshalb
  weder fälschlich als „kein Blocker" noch mit einem irreführenden Wert
  erscheinen (Plan-Nachzug Punkt 3, real getestet und unabhängig vom
  Verifier bestätigt, `docs/reviews/verify-slice-045.md` §3).
- d-migrate könnte für die neue View denselben `POST_EXECUTE_DRIFT`-
  Bootstrap-Bedarf zeigen wie frühere Views vor ihrer deklarativen
  Überführung (`BEO-PGC/d-migrate-nacharbeit`) — mittlerweile aber laut
  `harness/README.md` seit `slice-016` behoben für Views. **Ausgang:
  entfallen.** Real durch mehrere `make test-integration`-/
  `make test-store`-Läufe bestätigt: `schema migrate --execute` legt
  `cdc.retention_blockers` ohne `VIEW_SIGNATURE_UNKNOWN`-Blocker an,
  auch nach wiederholtem Lauf gegen eine bereits migrierte DB
  (`docs/reviews/verify-slice-045.md` §3).

## 7. Closure-Notiz

<!-- BEDIENHINWEIS — keine Norm; faellt beim Kopieren weg (README.md
§Verwendung, Schritt 5) und darf deshalb nichts Tragendes halten. Reihenfolge:
diese Sektion vor dem `git mv` nach done/ fuellen — einzige Ausnahme ist das
letzte DoD-Item in §2 (die Paarungen suchen in `done/`, also nach dem `git mv`).
Im Repo ohne Wellen-Betrieb braucht die Closure dadurch drei Commits: Inhalt,
`git mv`, Haekchen — das folgt aus der Hard Rule, es widerspricht ihr nicht. -->

Regeln dieser Sektion: Baseline-Regelwerk `modul-06-roadmap.md`
§Das Beobachtungs-Register (vorhandene `BEO-<NNN>` **zitieren** statt neu
formulieren — sonst zählt das Register zwei Namen getrennt) ·
`grundlagen-traceability.md` §Herkunfts-Anker für Steering-Loop-Regeln (das
Feld `liegt in` steht **nur**, wenn mit diesem Slice wirklich etwas verkörpert
wurde; Feld und Zielort auf **einer** Zeile, Sektionsangabe innerhalb der
Backticks).

- **Was hat funktioniert:** Die reine Projektions-View (`DISTINCT ON` über
  bestehende Tabellen) hielt den Slice tatsächlich auf drei Liefer-Punkte,
  ohne neue Go-Domain-/Use-Case-Logik zu berühren — Reviewer und Verifier
  bestätigen beide unabhängig, dass keine Duplikat-Logik zu
  `RetentionPolicy.AllowsDeletion` entstand. Der Implementer fand und behob
  einen realen Testfall-Hygiene-Fehler (liegen gebliebene
  Consumer-Positionen blockierten den bestehenden `slice-044`-Retention-
  Beleg) durch saubere Ursachen-Isolation (`git stash`-Vergleich gegen
  unveränderten `HEAD`) statt Symptom-Behandlung.
- **Was ging anders als geplant:** Der Reviewer markierte einen Punkt
  (Verhältnis der neuen View zu `LH-FA-RET-005`s Boundary-Kriterium)
  ausdrücklich als Verifier-Aufgabe statt ihn selbst zu bewerten — der
  Verifier klärte eigenständig, dass die Boundary bereits vor diesem Slice
  durch die bestehende `cdc.consumer_status`/`cdc_consumer_lag`-Kette
  gedeckt war (`docs/reviews/verify-slice-045.md` §2); kein Substanz-Mangel,
  nur eine Formulierungs-Unschärfe in DoD-Punkt 2. Der Verifier fand zudem
  erneut eine nicht nachgezogene DoD-Checkbox („Review durchgeführt" trotz
  sauberem Review ohne Fixrunde) — vierte Wiederholung dieser Symptom-Klasse
  (nach `slice-039`/`043`/`044`), diesmal aber strukturell distinkt von
  der bereits verkörperten `BEO-PGC/dod-checkbox-nachzug`-Regel: Diese
  deckt nur den Implementer-eigenen Lauf (Schritt 18) bzw. eine Fixrunde
  (Schritt 21) ab — bei einem sauberen Review ohne Fixrunde greift keiner
  der beiden Träger. Neue Beobachtung registriert (siehe unten), kein
  Architect-Zug ausgelöst (1×, unter der Schwelle).
- **Steering-Loop-Eintrag:** *(kein Eintrag verkörpert — der Normalfall.)*
- **Beobachtungs-Register (`../observations/`):**
  `BEO-PGC/dod-checkbox-nachzug-review-ohne-fixrunde` neu angelegt, Beleg
  `evidence/slice-045.md` — Zähler steht bei 1× (historische Vorkommen bei
  `slice-039`/`043`/`044` zählen laut Präzedenzfall `BEO-PGC/plan-nachzug`
  nicht, da vor der Registrierung). `BEO-PGC/retention-keine-
  loeschausfuehrung` bleibt bei 0× bis zur `welle-13`-Closure;
  `BEO-PGC/d-migrate-nacharbeit` unverändert bei 5× (bereits verkörpert).
- **Folge-Slices:** keine neuen — `slice-046` steht bereits in `welle-13` §4.
- **Risiken aus §6:** beide *entfallen* — siehe §6.
- **Drei Paarungen:** Repo **mit** Wellen-Betrieb (`welle-13` offen) — Prüfung
  für `retention-keine-loeschausfuehrung`/`slice-046` läuft bei der
  `welle-13`-Closure. Für die neu angelegte
  `BEO-PGC/dod-checkbox-nachzug-review-ohne-fixrunde` gilt: kein `liegt in`-Feld
  (Ausgang *weiter offen*, nichts verkörpert), also kein Anker-Paarungs-
  Gegenstand — nur die Register-Existenz zählt und ist hier bereits
  geprüft (Verzeichnis + nicht leeres `evidence/`).

## 8. Sub-Area-Prüfungen und Modus-Begründung

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Ziel-Form: Sub-Area-Modus-Begründung — dort die **zwei vorgelagerten
Schritte** (sie stehen in jedem Slice-Plan, unabhängig von Modus und
Slice-Typ) und die **vier Pflichtkriterien** (Konventionen-Dichte ·
Phase-Reife · Evidenz-/Diskrepanz-Risiko · Reconciliation-Aufwand), vier und
nicht mehr.

**Der Abschnitt selbst entfällt nie.** Die zwei vorgelagerten Prüfungen laufen
in **jedem** Slice-Plan — sie hängen weder am Modus noch am Slice-Typ. Bedingt
ist allein der Modus-Begründungsblock am Ende; deshalb nennt der Titel beide
Hälften.

**Vorgelagert — Sub-Area-Wahl prüfen:** Einzige berührte Sub-Area ist die
Repo-weite Default-Sub-Area `*`/`PGC`.

**Vorgelagert — offene Beobachtungen sichten:** Register durchgegangen.
Treffer für `PGC`: `BEO-PGC/retention-keine-loeschausfuehrung` (0×,
benannt nicht gezählt), `BEO-PGC/d-migrate-nacharbeit` (5×, bereits
verkörpert — für Views seit `slice-016` gelöst, siehe §6). Keiner
erreicht mit diesem Slice 3×.

**Modus-Begründungsblock — Umfang.** Pflicht, sobald mindestens eine berührte
Sub-Area BF oder Hybrid ist — einer pro Sub-Area. Bei reinem GF genügt der
Hinweis *"alle berührten Sub-Areas GF"*; bei reinem Refactor ohne neue
Sub-Area-Berührung entfällt **er** — nicht der Abschnitt.

Alle berührten Sub-Areas GF (nur `*`/`PGC`).
