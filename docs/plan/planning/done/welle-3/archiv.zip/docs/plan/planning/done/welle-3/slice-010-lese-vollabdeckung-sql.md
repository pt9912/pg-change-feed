# Slice slice-010: Lesen-Vollabdeckung und SQL-Schnittstelle

**Lifecycle:** Der Zustand dieses Slice ist das Verzeichnis, in dem diese
Datei liegt — eines von `open/`, `next/`, `in-progress/`, `done/`. Er
wechselt nur durch `git mv`, siehe
Baseline-Regelwerk `modul-05-planning-harness.md` §Lifecycle als State Machine.

**Welle:** welle-3.

**Bezug:** [`LH-FA-REA-002`](../../../../spec/lastenheft.md)…006, [`LH-FA-SST-002`](../../../../spec/lastenheft.md), [`ADR-0009`](../../../../docs/plan/adr/README.md), [`ADR-0046`](../../../../docs/plan/adr/README.md)

**Berührte Spec-Stellen:** [`ARC-005`](../../../../spec/architecture.md), [`ARC-006`](../../../../spec/architecture.md)
Der Verweis zeigt **aufwärts**: Die Spec nennt diesen Slice nie
(Baseline-Regelwerk `grundlagen-referenz-richtung.md`
§Referenz-Richtung (SDP), `grundlagen-source-precedence.md` §ID-Schema als Klammer).

**Verantwortlich:** pt9912.
**Autor:** pt9912. **Datum:** 2026-09-09.

---

## 1. Ziel und Abgrenzung

<!-- BEDIENHINWEIS: Ziel = ein Satz, Liefer-Fokus, kein "wir machen
aufraeumen". Abgrenzung = je Punkt eine Begruendung, nicht nur eine Nennung:
ein Ausschluss ohne Grund ist eine Behauptung. Keine Mindestzahl — ein echter
Ausschluss ist besser als vier erfundene. -->

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Ziel-Form: Slice — Schnitt nach Lieferwert, nicht nach Schichten; jeder Slice
ist einzeln lieferbar. **§1 nennt Ziel und Abgrenzung** (Out-of-Scope-Disziplin
des Lastenhefts, auf den Slice-Plan angewandt); die vier Klassen des
Ausschlusses stehen in **eben diesem Abschnitt** des Baseline-Regelwerks,
zusammen mit der Begründungs-Pflicht je Punkt.

**Ziel:** Lesen-Vollabdeckung am Store-Adapter real (Bereich/Limit/Filter/Wiederlesen je [`LH-FA-REA-001`](../../../../spec/lastenheft.md)…006) plus SQL-Adapter für SST-002 (Konfiguration, Status, Kernlesezugriffe über SQL-Views im cdc-Schema).

**Ausdrücklich NICHT in diesem Slice** — je Punkt mit Begründung:

- HTTP-/gRPC-API — bleibt optional ohne beobachtbaren Bedarf; die
  SQL-Views in diesem Slice sind kein API-Ersatz, sondern
  Konfiguration/Status-Abfrage am `cdc`-Schema.

**Keine Mindestzahl.** Ein Slice mit *einem* echten Ausschluss ist besser als
einer mit vier erfundenen; die vier Klassen sind ein Suchraster, keine
Ausfüll-Liste. Suchreihenfolge: Was übernimmt ein **Folge-Slice** (mit
Kennung — und die Kennung muss den Punkt auch annehmen)? Was bleibt als
**Bestand** bewusst stehen (mit Begründung)? Was wäre ein **anderer Vorgang**?
Welche **Schicht** rührt der Slice nicht an?

Was hier steht, ist die Grenze, an der ein wachsender Slice sich messen lässt:
Wer später etwas mitnimmt, das hier ausgeschlossen war, hat den Plan
**geändert**, nicht nur ergänzt.

## 2. Definition of Done

<!-- BEDIENHINWEIS: je Zeile ein pruefbares Kriterium. -->

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Ziel-Form: Slice — **≤ 3 Liefer-Punkte**; mehr heißt: der Slice ist zu groß und
gehört zurück zur Zerlegung. Gezählt wird nur, was mit dem Umfang wächst — die
Gate-Läufe und die fünf Closure-Pflichten darunter zählen nicht mit.

- [x] Lesen-Vollabdeckung am `PostgresChangeStoreAdapter` — Teil-Beleg
      zu [`LH-FA-REA-001`](../../../../spec/lastenheft.md)…006 (Bereich,
      Limit, Filter, Wiederlesen).
- [x] SQL-Views im `cdc`-Schema für SST-002 — Teil-Beleg zu
      [`LH-FA-SST-002`](../../../../spec/lastenheft.md).
- [x] `make gates` grün.
- [x] Review durchgeführt, Report unter `docs/reviews/` liegt vor
      (`.harness/skills/reviewer.md`) — Rollenwechsel nach Schritt 8 des
      Minimal Agent Workflow (`AGENTS.md` §6), kein Self-Review (Modul 8).
- [x] Doku-Update für `spec/architecture.md` (SQL-Lese-View-Kanal,
      [`LH-FA-REA-002`](../../../../spec/lastenheft.md)), falls berührt
      — geprüft: nachgezogen (`5365ee2`).
- [x] Closure-Notiz mit Steering-Loop-Lerneintrag.
- [x] Reconciliation-Register (`../reconciliation.md`) fortgeschrieben, **falls dieser Slice einen Inventur-Fund auflöst** — Zeile mit Datum und auflösendem Artefakt nach *Aufgelöste Einträge* verschoben. Repos ohne Brownfield-Bootstrap haben die Datei nicht; dann entfällt das Item.
- [x] Beobachtungs-Register (`../observations/`) fortgeschrieben — neues Verzeichnis `BEO-<KUERZEL>/<slug>/` oder eine weitere Datei in dessen `evidence/`; **kein Zaehler wird gesetzt**, er folgt aus den Dateien. Keine Beobachtung angefallen ist ebenfalls eine Antwort und wird in §7 notiert.
- [x] Jedes Risiko aus §6 trägt einen Ausgang (eingetreten / entfallen / weiter offen).
- [x] Die drei Paarungen (Anker · Folge-Slice · Register) sind getragen — im Repo **ohne** Wellen-Betrieb hier geprüft, im Repo **mit** Wellen von der nächsten Welle-Closure (auch für Slices ohne Wellen-Zugehörigkeit).

## 3. Plan (vor Code)

<!-- BEDIENHINWEIS: Datei- oder Komponenten-Ebene reicht; der
Implementer-Agent erweitert die Liste in seinem ersten Lauf. -->

Regeln dieser Sektion: Baseline-Regelwerk `grundlagen-bootstrap.md`
§Was ist eine Sub-Area? — diese Liste liefert die **Pfad-Kandidaten** für §8,
nicht die Antwort: Pfad-Berührung ist nicht hinreichend, und eine
Aussagen-Berührung steht hier gar nicht.

| Datei / Komponente | Änderungs-Art | Begründung |
|---|---|---|
| `internal/adapters/driven/postgresstorage/queries/*.go` | **entfällt (Plan-Nachzug)** | Ist-Zustand vor Code gemessen (Schritt 12, Implementer-Workflow): `SelectChanges` deckt Bereich ([`LH-FA-REA-001`](../../../../spec/lastenheft.md)), Startposition ([`LH-FA-REA-002`](../../../../spec/lastenheft.md)), Limit ([`LH-FA-REA-003`](../../../../spec/lastenheft.md)), Ordnung ([`LH-FA-REA-004`](../../../../spec/lastenheft.md)), Wiederlesen ([`LH-FA-REA-005`](../../../../spec/lastenheft.md)) und Tabellenfilter ([`LH-FA-REA-006`](../../../../spec/lastenheft.md)) bereits seit slice-004 vollständig ab — real gegen PostgreSQL belegt in `store_test.go` (`TestReadCarriesPositionsAndRanges`, `TestReadCarriesLimit`, `TestReadCarriesTableFilter`, `TestReadIsDeterministicallySorted`, `TestReadLeavesPersistedStateUnchanged`). Kein Diff nötig; die DoD-Zeile „Lesen-Vollabdeckung … Teil-Beleg" verweist auf diesen bestehenden Bestand |
| `tools/schema/schema.yaml` | update | SQL-Views (`active_tables`, `consumer_status`, `changes`) für [`LH-FA-SST-002`](../../../../spec/lastenheft.md) über die d-migrate-Rollout-Kette ([`ADR-0043`](../../../../docs/plan/adr/README.md)) — Kommentar-Block erweitert; lesen `cdc.*` direkt statt über Inbound Ports, je [`ADR-0046`](../../../../docs/plan/adr/README.md) (`Supersedes ADR-0018` für reine Lese-Views ohne Entscheidungslogik) |
| `tools/schema/nacharbeit-views.sql` | **neu (Plan-Nachzug)** | die drei Views selbst leben **nicht** im `views:`-Knoten von `schema.yaml`, sondern als berichtete manuelle Nacharbeit (dieselbe Ausweichform wie `nacharbeit-operation-check.sql`, [`ADR-0043`](../../../../docs/plan/adr/README.md) Re-Evaluierungs-Trigger): am realen Testcontainer rot gesehen — `schema migrate --execute` bricht mit „Post-execute compare detected drift" (Exit 5) ab, weil PostgreSQL die Katalogform eines `CREATE VIEW` über `pg_get_viewdef` umformatiert (Alias-Präfixe fallen, Einrückung ändert sich) und der textliche Vergleich das als Drift liest — derselbe `raw-sql-text-drift`-Befund wie bei `chk_change_operation` (`docs/plan/planning/observations/BEO-PGC/d-migrate-nacharbeit`, 2. Beleg) |
| `Makefile` (`schema-rollout`-Target) | **update (Plan-Nachzug)** | zweiter psql-Nacharbeit-Schritt für `nacharbeit-views.sql`, analog zum bestehenden Schritt für `nacharbeit-operation-check.sql` |
| `internal/adapters/driven/postgresstorage/sqlviews_test.go` | **neu (Plan-Nachzug)** | Teil-Beleg zu [`LH-FA-SST-002`](../../../../spec/lastenheft.md) am realen Testcontainer: die drei Views tragen Konfiguration, Status (inkl. Rückstand, [`LH-FA-ADM-005`](../../../../spec/lastenheft.md)) und Kernlesezugriff (Bereich/Limit/Filter/Ordnung über WHERE/LIMIT der `changes`-Sicht, [`LH-FA-REA-001`](../../../../spec/lastenheft.md)…006 gespiegelt auf SQL-Ebene) — läuft namensbedingt vor `store_test.go` (Datei-Namensordnung, Kommentar in der Datei trägt die Kopplung)

## 4. Trigger

<!-- BEDIENHINWEIS: Beispiele — "Wenn Welle X done." / "Wenn Carveout CO-NN
aufgeloest." -->

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Trigger je Lifecycle-Übergang und WIP-Limit.

**Start** (`next` → `in-progress`): slice-009 liegt in `done/`; kein anderes Slice in `in-progress/`
(WIP-Limit 1).

**Rückführungen — vorab benennen, nicht erst im Nachhinein begründen:**

- `in-progress` → `next` (zu groß, zurück zur Zerlegung): Vollabdeckung (Bereich/Limit/Filter/Wiederlesen) plus SQL-Views
  übersteigt drei Liefer-Punkte — Rückzug mit Zerlegung (SQL-Views
  als eigener Slice).
- `in-progress` → `open` (blockiert — Carveout?): d-migrate-Blocker (BEO-PGC/d-migrate-nacharbeit) verhindert die
  View-DDL im YAML-Rollout — Blocker, Carveout-Prüfung.

## 5. Closure-Trigger

<!-- BEDIENHINWEIS: z.B. "DoD vollstaendig + PR gemerged + Closure-Notiz
geschrieben." -->

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Closure- und Lerneintrag-Regeln — zwei beobachtbare Kriterien **und** ein
Lerneintrag; ohne ihn ist der Slice nur abgelegt.

- DoD vollständiges Häkchen + `make gates` grün + Review-Schluss
      ohne offenes HIGH-Finding; jede REA-Klasse am realen
      Store-Adapter belegt (beobachtbar am Test-Diff).
- Lerneintrag §7: geschärfte Regel oder benannte Spec-Lücke —
  ohne ihn bleibt der Slice abgelegt, nicht fertig.

## 6. Risiken und offene Punkte

<!-- BEDIENHINWEIS: Was koennte schief gehen? Welche Carveouts entstehen
ggf.? Die drei Ausgaenge stehen als Form in der Zeile darunter. -->

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Offene Risiken werden bei Closure aufgelöst — **jedes** Risiko bekommt genau
**einen** Ausgang, und kein Slice geht nach `done/`, während eines ohne Ausgang
dasteht.

- (a) SQL-Views im `cdc`-Schema konkurrieren mit den Use-Case-
  Lese-Pfaden (zwei Quellen für denselben Zustand) — **Ausgang:**
  weiter offen → `BEO-PGC/lese-doppelquelle` im Register (Eintrag
  angelegt, Beleg `evidence/slice-010.md`).

## 7. Closure-Notiz

<!-- BEDIENHINWEIS — keine Norm; faellt beim Kopieren weg (README.md
§Verwendung, Schritt 5) und darf deshalb nichts Tragendes halten. Reihenfolge:
diese Sektion vor dem `git mv` nach done/ fuellen — einzige Ausnahme ist das
letzte DoD-Item in §2 (die Paarungen suchen in `done/`, also nach dem `git mv`).
Im Repo ohne Wellen-Betrieb braucht die Closure dadurch drei Commits: Inhalt,
`git mv`, Haekchen — das folgt aus der Hard Rule, es widerspricht ihr nicht. -->

Regeln dieser Sektion: Baseline-Regelwerk `modul-06-roadmap.md`
§Das Beobachtungs-Register (vorhandene `BEO-<NNN>` **zitieren** statt neu
formulieren — sonst zählt das Register zwei Namen getrennt) ·
`grundlagen-traceability.md` §Herkunfts-Anker für Steering-Loop-Regeln (das
Feld `liegt in` steht **nur**, wenn mit diesem Slice wirklich etwas verkörpert
wurde; Feld und Zielort auf **einer** Zeile, Sektionsangabe innerhalb der
Backticks).

- **Was hat funktioniert:** Der Implementer-Zug maß den Ist-Zustand vor
  Code (§Plan vor Code, Schritt 12) und fand, dass die geplante
  Lesen-Vollabdeckung bereits seit slice-004 vollständig belegt war —
  kein Diff, sondern ein gemessener Bestand; der Verifier bestätigte
  das unabhängig gegen die realen Store-Tests. Die neue Plan-Nachzug-
  Pflicht (seit slice-009) bestand ihren ersten Praxistest sauber
  (Commit-Reihenfolge korrekt, §3 vollständig).
- **Was ging anders als geplant:** Die drei SQL-Views trafen einen
  echten Rollen-Widerspruch (Review F-1, HIGH): [`ADR-0018`](../../../../docs/plan/adr/README.md)
  verlangt Inbound-Port-Aufrufe für SQL-Driving-Adapter, was für reine
  Lese-Views physikalisch nicht möglich ist. Architect-Verdikt:
  [`ADR-0046`](../../../../docs/plan/adr/README.md) (`Supersedes ADR-0018`)
  trennt Lese-Views (keine Entscheidungslogik, direkter Lesezugriff
  zulässig) von schreibenden SQL-Funktionen (bleiben portgebunden).
  `spec/architecture.md` wurde entsprechend nachgezogen (kein
  ADR-Bezug in der Sicht selbst, Hard Rule 3.4). Zusätzlich: derselbe
  d-migrate-`raw-sql-text-drift`-Blocker aus slice-006 traf jetzt auch
  gespeicherte Views (PostgreSQL-Umformatierung via `pg_get_viewdef`) —
  zweite Ausweichform nötig. Und: die Verifikation deckte eine
  4./3. Wiederholung der Dup-DoD-/Platzhalter-Klasse auf, die außerhalb
  jedes Implementer-Diffs lag (§2 war seit der welle-3-Eröffnung nie
  berührt worden).
- **Steering-Loop-Eintrag:** Planner-Workflow geschärft (§2-Form-
  Prüfung nach dem Füllen mehrerer Slices in einem Zug) — liegt in
  `.claude/commands/plan-welle.md §Slices bereitstellen`.
  Auslöser: `BEO-PGC/plan-vorlagen-defekt` (slice-005, slice-008,
  slice-009 — 3×).
- **Beobachtungs-Register (`../observations/`):** `evidence/slice-010.md`
  in `BEO-PGC/d-migrate-nacharbeit/` ergänzt (Zähler 2×, weiter offen);
  `BEO-PGC/plan-vorlagen-defekt/` neu angelegt und auf *verkörpert*
  gesetzt (Beleg aus slice-005/008/009, 3×); `BEO-PGC/lese-doppelquelle/`
  neu angelegt (Beleg `evidence/slice-010.md`, 1×, weiter offen).
- **Folge-Slices:** keine.
- **Risiken aus §6:** (a) SQL-Views vs. Use-Case-Lesepfade — weiter
  offen → `BEO-PGC/lese-doppelquelle` im Register.
- **Drei Paarungen:** entfällt hier — das Repo arbeitet mit Wellen;
  die Welle-3-Closure prüft Anker · Folge-Slice · Register auch für
  diesen Slice.

## 8. Sub-Area-Prüfungen und Modus-Begründung

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Ziel-Form: Sub-Area-Modus-Begründung — dort die **zwei vorgelagerten
Schritte** (sie stehen in jedem Slice-Plan, unabhängig von Modus und
Slice-Typ) und die **vier Pflichtkriterien** (Konventionen-Dichte ·
Phase-Reife · Evidenz-/Diskrepanz-Risiko · Reconciliation-Aufwand), vier und
nicht mehr.

**Der Abschnitt selbst entfällt nie.** Die zwei vorgelagerten Prüfungen laufen
in **jedem** Slice-Plan — sie hängen weder am Modus noch am Slice-Typ. Bedingt
ist allein der Modus-Begründungsblock am Ende; deshalb nennt der Titel beide
Hälften.

**Vorgelagert — Sub-Area-Wahl prüfen:** Die berührten Sub-Areas
(Store-Adapter/Lesepfad, Schemamigration/SQL-Views) sind Segmente des
GF-Baums der Modus-Deklaration (`PGC` Greenfield, Doc führt) — jede
erfüllt die Schwelle ≥ 2 von 3 Achsen: Strukturregeln im Spec-Stratum
committet, Phase-Reife 3–4, Evidenz-/Diskrepanz-Risiko niedrig. Keine
Sub-Area zu grob.

**Vorgelagert — offene Beobachtungen sichten:** Register gelesen (sechs
Einträge zum Zeitpunkt dieser Nachpflege): `d-migrate-nacharbeit` 2×
(dieser Slice ist sein 2. Beleg — SQL-Views trafen dieselbe
`raw-sql-text-drift`-Grenze), `plan-nachzug` verkörpert (2×, nicht
berührt — die Regel hielt in diesem Lauf), `plan-vorlagen-defekt`
verkörpert (3×, dieser Slice war der Auslöser der Verifikations-Findung
V-1, die zur Registrierung führte — die Klasse selbst betraf slice-005/
008/009 als Beleg), `adapter-fehler-ausgang` 1× (nicht berührt),
`walsender-wirksamkeit` 1× (nicht berührt), `a-check-null-abdeckung`
verkörpert (seit welle-1). Kein Eintrag erreicht mit diesem Slice neu
3× (die beiden verkörperten waren es bereits vor diesem Slice).

**Modus-Begründungsblock — Umfang.** Pflicht, sobald mindestens eine berührte
Sub-Area BF oder Hybrid ist — einer pro Sub-Area. Bei reinem GF genügt der
Hinweis *"alle berührten Sub-Areas GF"*; bei reinem Refactor ohne neue
Sub-Area-Berührung entfällt **er** — nicht der Abschnitt.

<!-- Block für jede berührte Sub-Area duplizieren. Format identisch
mit dem im Baseline-Regelwerk §Ziel-Form: Sub-Area-Modus-Begründung
abgedruckten Block. -->

*Reiner GF-Hinweis genügt (siehe oben); kein Sub-Area-Block.*
