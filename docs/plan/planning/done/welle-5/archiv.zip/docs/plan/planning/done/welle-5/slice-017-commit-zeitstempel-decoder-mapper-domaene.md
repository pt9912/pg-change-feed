# Slice slice-017: Commit-Zeitstempel — Decoder, Mapper, Domäne

**Lifecycle:** Der Zustand dieses Slice ist das Verzeichnis, in dem diese
Datei liegt — eines von `open/`, `next/`, `in-progress/`, `done/`. Er
wechselt nur durch `git mv`, siehe
Baseline-Regelwerk `modul-05-planning-harness.md` §Lifecycle als State Machine.

**Welle:** [`welle-5`](welle-5.md) — die Ende-zu-Ende-Belegpflicht
(Lasttest gegen einen real abgebildeten Verzögerungs-Wert) geht über die
DoD dieses einzelnen Slice hinaus.

**Bezug:** [`LH-FA-ADM-004`](../../../../spec/lastenheft.md)

**Berührte Spec-Stellen:** —

**Verantwortlich:** pt9912.

**Autor:** pt9912. **Datum:** 2026-09-12.

---

## 1. Ziel und Abgrenzung

<!-- BEDIENHINWEIS: Ziel = ein Satz, Liefer-Fokus, kein "wir machen
aufraeumen". Abgrenzung = je Punkt eine Begruendung, nicht nur eine Nennung:
ein Ausschluss ohne Grund ist eine Behauptung. Keine Mindestzahl — ein echter
Ausschluss ist besser als vier erfundene. -->

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Ziel-Form: Slice — Schnitt nach Lieferwert, nicht nach Schichten; jeder Slice
ist einzeln lieferbar. **§1 nennt Ziel und Abgrenzung** (Out-of-Scope-Disziplin
des Lastenhefts, auf den Slice-Plan angewandt); die vier Klassen des
Ausschlusses stehen in **eben diesem Abschnitt** des Baseline-Regelwerks,
zusammen mit der Begründungs-Pflicht je Punkt.

**Ziel:** Den von `pglogrepl` bereits gelieferten
`CommitMessage.CommitTime`-Zeitstempel durch den Replication-Decoder, den
Mapper und die Domäne (`model.ChangeTransaction`) spiegeln, sodass der
reale Quell-Commit-Zeitpunkt ab dem Domänenmodell abrufbar ist — rein
unit-testbar, ohne Datenbankanbindung.

**Ausdrücklich NICHT in diesem Slice** — je Punkt mit Begründung:

- Persistenz des Zeitstempels in `cdc.transaction.committed_at` —
  Folge-Slice slice-018 (Store-Adapter-Schicht, eigene Testbarkeit gegen
  reale PostgreSQL).
- Metrik-Umbenennung `cdc_capture_lag_approx` → `cdc_capture_lag` und der
  Ende-zu-Ende-Lasttest-Beleg — Folge-Slice slice-019 (Closure-Trigger der
  Welle, setzt den real gespeicherten Wert aus slice-018 voraus).

**Keine Mindestzahl.** Ein Slice mit *einem* echten Ausschluss ist besser als
einer mit vier erfundenen; die vier Klassen sind ein Suchraster, keine
Ausfüll-Liste. Suchreihenfolge: Was übernimmt ein **Folge-Slice** (mit
Kennung — und die Kennung muss den Punkt auch annehmen)? Was bleibt als
**Bestand** bewusst stehen (mit Begründung)? Was wäre ein **anderer Vorgang**?
Welche **Schicht** rührt der Slice nicht an?

Was hier steht, ist die Grenze, an der ein wachsender Slice sich messen lässt:
Wer später etwas mitnimmt, das hier ausgeschlossen war, hat den Plan
**geändert**, nicht nur ergänzt.

## 2. Definition of Done

<!-- BEDIENHINWEIS: je Zeile ein pruefbares Kriterium. -->

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Ziel-Form: Slice — **≤ 3 Liefer-Punkte**; mehr heißt: der Slice ist zu groß und
gehört zurück zur Zerlegung. Gezählt wird nur, was mit dem Umfang wächst — die
Gate-Läufe und die fünf Closure-Pflichten darunter zählen nicht mit.

- [x] `decode.Commit` trägt `CommitTime` (aus
      `pglogrepl.CommitMessage.CommitTime`) — real gegen eine dekodierte
      Beispiel-COMMIT-Nachricht getestet. Beleg: `TestDecodeFlowToCapture`
      (Commit `3fa7e5d`), real durch alle drei Schichten getrieben,
      Verifier bestätigt eigenständig.
- [x] `mapper.Assembler.Consume` übergibt den Zeitstempel beim
      Commit-Aufruf an `model.ChangeTransaction.Commit`; die Domäne
      speichert ihn und stellt einen Zugriff bereit — bestehende
      Invarianten (einmaliger Commit, gleiche Quelle) bleiben unverändert
      getestet grün. Beleg: Mutation-Test real reproduziert (Verifier,
      `verify-slice-017.md`) — Entfernen der Zuweisung lässt drei Tests
      rot laufen.
- [x] `make gates` grün.
- [x] Review durchgeführt, Report unter `docs/reviews/` liegt vor
      (`.harness/skills/reviewer.md`) — Rollenwechsel nach Schritt 8 des
      Minimal Agent Workflow (`AGENTS.md` §6), kein Self-Review (Modul 8).
      Beleg: [`review-slice-017.md`](../../../../docs/reviews/review-slice-017.md)
      (F-1 MEDIUM/F-2 LOW, beide als Selbstauskunfts-Korrektur ohne
      Repo-Änderung disponiert), Verifier bestätigt in
      [`verify-slice-017.md`](../../../../docs/reviews/verify-slice-017.md).
- [x] Doku-Update falls öffentlicher Vertrag berührt — geprüft: reine
      interne Signatur-Änderung (Domäne + Driving-Adapter), der
      `ChangeStorePort` bleibt unverändert — Item entfällt.
- [x] Closure-Notiz mit Steering-Loop-Lerneintrag.
- [x] Reconciliation-Register (`../reconciliation.md`) fortgeschrieben, **falls dieser Slice einen Inventur-Fund auflöst** — Zeile mit Datum und auflösendem Artefakt nach *Aufgelöste Einträge* verschoben. Repos ohne Brownfield-Bootstrap haben die Datei nicht; dann entfällt das Item. Geprüft: Datei existiert nicht (GF-Repo) — entfällt.
- [x] Beobachtungs-Register (`../observations/`) fortgeschrieben — neues Verzeichnis `BEO-<KUERZEL>/<slug>/` oder eine weitere Datei in dessen `evidence/`; **kein Zaehler wird gesetzt**, er folgt aus den Dateien. Keine Beobachtung angefallen ist ebenfalls eine Antwort und wird in §7 notiert. Beleg: `BEO-PGC/dod-checkbox-nachzug/` neu angelegt, 3. Beleg — Ausgang bei `welle-5`-Closure.
- [x] Jedes Risiko aus §6 trägt einen Ausgang (eingetreten / entfallen / weiter offen). Siehe §6.
- [x] Die drei Paarungen (Anker · Folge-Slice · Register) sind getragen — im Repo **ohne** Wellen-Betrieb hier geprüft, im Repo **mit** Wellen von der nächsten Welle-Closure (auch für Slices ohne Wellen-Zugehörigkeit). Dieser Slice gehört zu `welle-5` — die Paarungen prüft die **Welle-Closure**, nicht dieser Slice. Item entfällt hier bewusst.

## 3. Plan (vor Code)

<!-- BEDIENHINWEIS: Datei- oder Komponenten-Ebene reicht; der
Implementer-Agent erweitert die Liste in seinem ersten Lauf. -->

Regeln dieser Sektion: Baseline-Regelwerk `grundlagen-bootstrap.md`
§Was ist eine Sub-Area? — diese Liste liefert die **Pfad-Kandidaten** für §8,
nicht die Antwort: Pfad-Berührung ist nicht hinreichend, und eine
Aussagen-Berührung steht hier gar nicht.

| Datei / Komponente | Änderungs-Art | Begründung |
|---|---|---|
| `internal/adapters/driving/replication/decode/decode.go` | update | `Commit`-Event trägt `CommitTime` (`time.Time`, aus `pglogrepl.CommitMessage.CommitTime`) |
| `internal/adapters/driving/replication/mapper/mapper.go` | update | `Consume` übersetzt `CommitTime` in `model.TimePoint` (`ADR-0040` — Domain importiert `time` nicht) und übergibt sie an `Commit()` |
| `internal/domain/model/transaction.go` | update | `Commit(position, sourceCommittedAt TimePoint)`-Signatur + Zugriff `SourceCommittedAt()`; Feld bleibt `TimePoint`, kein `time.Time` (`ADR-0040`) |
| zugehörige `_test.go`-Dateien der drei obigen Pakete | update | Tests für den neuen Zeitstempel-Fluss, inkl. Ende-zu-Ende-Beleg `TestDecodeFlowToCapture` |
| **Plan-Nachzug (§6-Risiko eingetreten, im Rahmen absorbiert):** `internal/bootstrap/heartbeat_internal_test.go`, `internal/adapters/driven/postgresstorage/store_test.go` (zwei Stellen), `internal/application/usecase/capture/service_test.go` | update | Vier Aufrufstellen von `tx.Commit(position)` außerhalb der drei geplanten Pakete — reine Test-Fixtures, die die neue Signatur mit einem Platzhalter-Zeitstempel (`model.NewTimePoint(1)`) bedienen; keine Design-Änderung, kein Umbau nötig |

## 4. Trigger

<!-- BEDIENHINWEIS: Beispiele — "Wenn Welle X done." / "Wenn Carveout CO-NN
aufgeloest." -->

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Trigger je Lifecycle-Übergang und WIP-Limit.

**Start** (`next` → `in-progress`): kein anderes Slice in `in-progress/`
(WIP-Limit 1); `welle-5` ist eröffnet.

**Rückführungen — vorab benennen, nicht erst im Nachhinein begründen:**

- `in-progress` → `next` (zu groß, zurück zur Zerlegung): Falls die
  gepinnte `pglogrepl`-Version kein `CommitTime`-Feld an
  `CommitMessage` führt und ein größerer Umbau des Decoders nötig wird —
  Rückzug mit Zerlegung.
- `in-progress` → `open` (blockiert — Carveout?): Falls die
  Signatur-Änderung an `ChangeTransaction.Commit` unerwartet viele
  Call-Sites außerhalb der drei genannten Pakete bricht und den Umfang
  sprengt — Blocker, Carveout-Prüfung.

## 5. Closure-Trigger

<!-- BEDIENHINWEIS: z.B. "DoD vollstaendig + PR gemerged + Closure-Notiz
geschrieben." -->

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Closure- und Lerneintrag-Regeln — zwei beobachtbare Kriterien **und** ein
Lerneintrag; ohne ihn ist der Slice nur abgelegt.

- DoD vollständiges Häkchen + `make gates` grün + Review-Schluss ohne
  offenes HIGH-Finding; Unit-Tests belegen den Zeitstempel-Fluss von der
  dekodierten `pgoutput`-Nachricht bis zum Domänen-Zugriff.
- Lerneintrag §7: was beim Signatur-Umbau über drei Schichten gut oder
  schlecht lief.

## 6. Risiken und offene Punkte

<!-- BEDIENHINWEIS: Was koennte schief gehen? Welche Carveouts entstehen
ggf.? Die drei Ausgaenge stehen als Form in der Zeile darunter. -->

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Offene Risiken werden bei Closure aufgelöst — **jedes** Risiko bekommt genau
**einen** Ausgang, und kein Slice geht nach `done/`, während eines ohne Ausgang
dasteht.

- `pglogrepl.CommitMessage.CommitTime` könnte ohne klare Zeitzonen-Angabe
  vorliegen (naive `time.Time`) und zu einem Missverständnis über UTC vs.
  lokale Zeit führen. **Ausgang: entfallen.** Real geklärt (Reviewer +
  Verifier, unabhängig reproduziert): `pglogrepl.pgTimeToTime` liefert
  `Location=Local`, nicht UTC — der Code bleibt trotzdem korrekt, weil
  `mapper.go` ausschließlich `.UnixNano()` nutzt und die Tests `.Equal()`
  verwenden, beide location-unabhängig auf dem absoluten Zeitinstant.
- Die Signatur-Änderung an `ChangeTransaction.Commit` könnte mehr
  Test-Fixtures berühren als die drei geplanten Pakete. **Ausgang:
  entfallen.** Vier zusätzliche Call-Sites traten auf (Plan-Nachzug §3),
  aber Implementer, Reviewer und Verifier stimmen unabhängig überein:
  bounded, mechanisch, kein Rückführungs-Trigger im Sinne von §4.

## 7. Closure-Notiz

<!-- BEDIENHINWEIS — keine Norm; faellt beim Kopieren weg (README.md
§Verwendung, Schritt 5) und darf deshalb nichts Tragendes halten. Reihenfolge:
diese Sektion vor dem `git mv` nach done/ fuellen — einzige Ausnahme ist das
letzte DoD-Item in §2 (die Paarungen suchen in `done/`, also nach dem `git mv`).
Im Repo ohne Wellen-Betrieb braucht die Closure dadurch drei Commits: Inhalt,
`git mv`, Haekchen — das folgt aus der Hard Rule, es widerspricht ihr nicht. -->

Regeln dieser Sektion: Baseline-Regelwerk `modul-06-roadmap.md`
§Das Beobachtungs-Register (vorhandene `BEO-<NNN>` **zitieren** statt neu
formulieren — sonst zählt das Register zwei Namen getrennt) ·
`grundlagen-traceability.md` §Herkunfts-Anker für Steering-Loop-Regeln (das
Feld `liegt in` steht **nur**, wenn mit diesem Slice wirklich etwas verkörpert
wurde; Feld und Zielort auf **einer** Zeile, Sektionsangabe innerhalb der
Backticks).

- **Was hat funktioniert:** Reale Mutation-Tests (Zeile entfernt/verändert,
  Tests laufen lassen, zurücksetzen) haben zweimal — bei Implementer UND
  unabhängig beim Reviewer/Verifier — belegt, dass die neuen Tests den
  Zeitstempel-Fluss tatsächlich erzwingen, nicht nur behaupten. Der von
  [`ADR-0040`](../../../../docs/plan/adr/0040-clockport.md) verlangte
  `TimePoint`-statt-`time.Time`-Weg in der Domäne wurde
  vom Implementer selbst erkannt, ohne dass der Auftrag ihn nannte.
- **Was ging anders als geplant:** Zwei kleine Ungenauigkeiten in
  mündlichen Zwischenberichten (nicht im Repo-Inhalt selbst) — eine
  falsche Zeitzonen-Begründung und eine untertriebene Mutation-Test-Zahl
  — wurden vom Reviewer und dann vom Verifier unabhängig aufgedeckt und
  korrigiert, ohne dass eine Repo-Änderung nötig war.
- **Steering-Loop-Eintrag:** Mit diesem Slice wurde nichts verkörpert —
  das dritte Auftreten der Finding-Klasse „DoD-Checkboxen bleiben
  ungesetzt trotz materieller Erledigung" ist als neue Beobachtung
  erfasst, aber der Lese-Schritt (Ausgang zuweisen) fällt der
  `welle-5`-Closure zu, nicht diesem Einzel-Slice. Der Eintrag ist
  gezählt, nicht verkörpert.
- **Beobachtungs-Register (`../observations/`):** `evidence/slice-017.md`
  in `BEO-PGC/dod-checkbox-nachzug/` neu angelegt (rückwirkend auch
  `evidence/slice-015.md`/`slice-016.md` ergänzt) — Zähler steht bei 3×,
  Ausgang steht bei `welle-5`-Closure aus.
- **Folge-Slices:** keine — slice-018 und slice-019 sind bereits Teil
  derselben Welle und lagen von Anfang an in `open/`/`next/`, keine neue
  Kennung.
- **Risiken aus §6:** beide `entfallen` (siehe §6).
- **Drei Paarungen:** entfällt hier — dieser Slice gehört zu `welle-5`;
  die Paarungen prüft die Welle-Closure für alle drei Slices gemeinsam.

## 8. Sub-Area-Prüfungen und Modus-Begründung

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Ziel-Form: Sub-Area-Modus-Begründung — dort die **zwei vorgelagerten
Schritte** (sie stehen in jedem Slice-Plan, unabhängig von Modus und
Slice-Typ) und die **vier Pflichtkriterien** (Konventionen-Dichte ·
Phase-Reife · Evidenz-/Diskrepanz-Risiko · Reconciliation-Aufwand), vier und
nicht mehr.

**Der Abschnitt selbst entfällt nie.** Die zwei vorgelagerten Prüfungen laufen
in **jedem** Slice-Plan — sie hängen weder am Modus noch am Slice-Typ. Bedingt
ist allein der Modus-Begründungsblock am Ende; deshalb nennt der Titel beide
Hälften.

**Vorgelagert — Sub-Area-Wahl prüfen:** Die berührte Sub-Area
(Replication-Adapter/Domäne) ist ein Segment des GF-Baums der
Modus-Deklaration (`PGC` Greenfield, Doc führt) — erfüllt die Schwelle
≥ 2 von 3 Achsen. Nicht zu grob.

**Vorgelagert — offene Beobachtungen sichten:** Register gelesen (elf
Einträge zum Zeitpunkt der Planung): `cdc-capture-lag-real` 1× — genau
die von dieser Welle adressierte Beobachtung; dieser Slice liefert noch
keinen Beleg (technisch noch nicht real gespeichert, das folgt in
slice-018/019). Übrige zehn ohne Bezug:
`a-check-null-abdeckung` (3×, verkörpert), `adapter-fehler-ausgang` (1×),
`d-migrate-nacharbeit` (4×, verkörpert), `health-endpoint-heartbeat`
(2×, eingetreten), `lese-doppelquelle` (2×), `plan-nachzug` (2×,
verkörpert), `plan-vorlagen-defekt` (3×, verkörpert),
`rollen-verdrahtung` (1×), `schema-rollout-fremdobjekte` (1×),
`walsender-wirksamkeit` (1×). Kein Eintrag erreicht mit diesem Slice
3× — keine Lücke.

**Modus-Begründungsblock — Umfang.** Reiner GF-Hinweis genügt (siehe oben);
kein Sub-Area-Block.
